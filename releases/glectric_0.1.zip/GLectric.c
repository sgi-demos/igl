// Exclude rarely-used stuff from Windows headers
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT    0x0500  // for WM_MOUSEWHEEL

#include <windows.h>
#include <windowsx.h>
#include <wingdi.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>
#include <mmsystem.h>
#include <GL/gl.h>
#include <GL/glu.h>



#define GLSAVER_DEVEL   0       // development version

typedef int boolean;
#define true 1
#define false 0


//
// globals + defines
//
HWND hWnd;
HMIDIOUT midiHandle;
unsigned long midiMsg;
unsigned int fontBase;

int winWidth = 800;
int winHeight = 600;
boolean windowMode = false;

double xrot, yrot, zrot;
double mousex, mousey, mousez;
double camx = -2.5, camy = -2.5, camz = -30.0;


typedef struct
{
    double x, y, z;
    double r, g, b;
    double xrot, yrot, zrot;
    int groupId;
    unsigned long moveTime;
    unsigned long rotationTime;
    unsigned long colorTime;
    double moveClock;
    double rotationClock;
    double colorClock;
} squareT;

#define NUM_SQUARES 80
squareT squares[NUM_SQUARES];
#define MAX_POINTS  50          // used to be max vertices


/*********************************
    user-controled parameters
*********************************/
boolean drawSquareBorders = false;
boolean squarePersonality = false;
boolean rotateCamera = false;
boolean clearColorOnRender = true;
boolean soundEnabled = false;
boolean lightingEnabled = true;
boolean transparencyEnabled = true;
boolean showInfo = false;


/*********************************
    statistics
*********************************/
#define STEP 10
#define SMOOTHNESS 20
unsigned long numRenderedFrames = 0;
unsigned long tickStart;


/**************************************
    function definitions
**************************************/
void
openGl_fullscreen (boolean fullscreen);

void
_openGl_initSquares ();


/**************************************
    GLectric modules
**************************************/
void
_openGl_render_squareRoots ();

void
_openGl_render_dancingPolaroids ();

void
_openGl_render_wishingWell ();

void
_openGl_render_bipolarAttractors ();

void
_openGl_render_polarFlowers ();

void
_openGl_render_turbulenceBubble ();

void
_openGl_render_oscilloscope ();

void
_openGl_render_brokenMosaic ();


typedef struct
{
    void (*function)();
    char key;   // key to invoke this saver
    char *description;
} glectricModuleT;

glectricModuleT glectricModules[] =
{
    { _openGl_render_squareRoots,           '1', "Square roots"             },
    { _openGl_render_dancingPolaroids,      '2', "Dancing polaroids"        },
    { _openGl_render_wishingWell,           '3', "Wishing well"             },
    { _openGl_render_bipolarAttractors,     '4', "Bipolar attractors *+"    },
    { _openGl_render_polarFlowers,          '5', "Polar flowers *+"         },
    { _openGl_render_turbulenceBubble,      '6', "Turbulence bubble *+"     },
    { _openGl_render_oscilloscope,          '7', "Oscilloscope *+"          },
    { _openGl_render_brokenMosaic,          '8', "Broken mosaic"            },

    { NULL, '\0', "" }
};

void (*renderFunction) ();


#ifndef M_PI
#   define M_PI 3.1415926536
#endif
#define drand48() ((double)rand () / RAND_MAX)


#if 0
____________________________ Macros ____________________________
() {}
#endif
#define FCN_EXIT(condition_, ret_, action_) \
{                                           \
    if (condition_)                         \
    {                                       \
        ret = ret_;                         \
        action_;                            \
        goto exit;                          \
    }                                       \
}




#if 0
____________________________ MATH helpers ____________________________
() {}
#endif
double
math_sinGenerator (double t, unsigned long period, unsigned long seed, double min, double max)
{
    return ((max+min)/2 + ((max-min)/2)*sin((t+seed)*2*M_PI/(double)period));
}


double
math_peakGenerator (double t, unsigned long period, unsigned long seed, double min, double max)
{
    double arg, s;


    t += seed;

    if ((long)t % period > period/2)
    {
        t = (double)((long)t % period);
        if (t < 98*period/100)
        {
            return (min);
        }
        else
        {
            double td;


            t -= 98*period/100;
            td = t*50/(double)period;

            return (min + (max-min)*td*td);
        }
    }
    
    arg = t * M_PI / (double)period;
    s = 1 - (double)fabs(sin(arg));
    s = s*s*s;

    return min + (max - min) * s;
}


void
osc_nextMove (squareT *vptr, int numVertices)
{
    int i, oscType = 0;
    squareT *s = vptr;
    static double clk = 0, clrClk = 0;


    for (i=0; i < numVertices; i++)
    {
        s->x = math_sinGenerator (s->x, 31, i, 0, 5);
        s->y = math_sinGenerator (s->y, 31, i, 0, 5);
        s->z = math_sinGenerator (s->z, 31, i, 0, 5);

        s->r = math_sinGenerator (clrClk, 2, 2, 0.1, 1);
        s->g = math_sinGenerator (clrClk, 3, 2, 0.1, 1);
        s->b = math_sinGenerator (clrClk, 5, 2, 0.1, 1);
        clrClk += (math_sinGenerator(sin(clrClk), 100, i, 0, 1)/10000);

        s++;
    }
}


#if 0
____________________________ OpenGL helpers ____________________________
() {}
#endif
static void
openGl_init (HWND hWnd, HDC *hDC, HGLRC *hRC)
{
    int format;
    PIXELFORMATDESCRIPTOR pfd;
    HFONT font, oldFont;


    // get the device context (DC)
    *hDC = GetDC (hWnd);

    // set the pixel format for the DC
    ZeroMemory (&pfd, sizeof( pfd ));
    pfd.nSize = sizeof (pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    pfd.cDepthBits = 16;
    pfd.iLayerType = PFD_MAIN_PLANE;
    format = ChoosePixelFormat (*hDC, &pfd);
    SetPixelFormat (*hDC, format, &pfd);

    // create and enable the render context (RC)
    *hRC = wglCreateContext (*hDC);
    wglMakeCurrent (*hDC, *hRC);

    renderFunction = glectricModules[0].function;

    if (!windowMode)
    {
        // fullscreen mode
        openGl_fullscreen (true);
    }

    // create the font list
    font = CreateFont (16, 8, 0, 0, FW_LIGHT, FALSE, FALSE, FALSE, ANSI_CHARSET,
            OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
            FF_DONTCARE | DEFAULT_PITCH, "Verdana");
    oldFont = (HFONT)SelectObject (*hDC, font);

    fontBase = glGenLists (96);
    wglUseFontBitmaps (*hDC, 32, 96, fontBase);
    SelectObject (*hDC, oldFont);
    DeleteObject (font);
}


static void
openGl_cleanup (HWND hWnd, HDC hDC, HGLRC hRC)
{
    // close fullscreen mode
    openGl_fullscreen (false);

    // release the font bitmaps
    if (fontBase != 0)
    {
        glDeleteLists (fontBase, 96);
    }

    // release OpenGL contexts
    wglMakeCurrent (NULL, NULL);
    if (hRC != NULL)
    {
        wglDeleteContext (hRC);
    }
    if (hDC != NULL)
    {
        ReleaseDC (hWnd, hDC);
    }
}


void
openGl_fullscreen (boolean fullscreen)
{
    int wndStyle;
    DEVMODE devMode;


    memset (&devMode, 0, sizeof(DEVMODE));
    devMode.dmSize = sizeof (DEVMODE);
    wndStyle = GetWindowLong (hWnd, GWL_STYLE);

    if (fullscreen)
    {
        wndStyle &= ~WS_CAPTION;

        EnumDisplaySettings (NULL, ENUM_CURRENT_SETTINGS, &devMode);
        devMode.dmPelsWidth = winWidth;
        devMode.dmPelsHeight = winHeight;
        ChangeDisplaySettings (&devMode, CDS_FULLSCREEN);
        ShowCursor (FALSE);
    }
    else
    {
        wndStyle |= WS_CAPTION;
        ChangeDisplaySettings (&devMode, 0);
        ShowCursor (TRUE);
    }

    SetWindowLong (hWnd, GWL_STYLE, wndStyle);
}


int
openGl_setupScene ()
{
    GLfloat lightPosition[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
    GLfloat lightAmbient[4] = { 0.5f, 0.5f, 0.5f, 1.0f };
    GLfloat lightRed[4] = { 1.0f, 0.0f, -1.0f, 0.0f };
    GLfloat lightGreen[4] = { -1.0f, 1.0f, 0.0f, 0.0f };
    GLfloat lightBlue[4] = { -1.0f, 0.0f, 1.0f, 0.0f };


    glClearColor (0.0f, 0.0f, 0.0f, 1.0f);
    glEnable (GL_NORMALIZE);
    glShadeModel (GL_SMOOTH);
    glDisable (GL_BLEND);
    glEnable (GL_DEPTH_TEST);
    glEnable (GL_TEXTURE_2D);
    glEnable (GL_DITHER);

    glFrontFace (GL_CCW);

    glEnable (GL_LIGHT0);
    glEnable (GL_LIGHT1);
    glEnable (GL_LIGHT2);
    if (lightingEnabled)
    {
        glEnable (GL_LIGHTING);
    }
    else
    {
        glDisable (GL_LIGHTING);
    }

    if (transparencyEnabled)
    {
        glDisable (GL_DEPTH_TEST);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE);
        glEnable (GL_BLEND);
    }
    else
    {
        glEnable (GL_DEPTH_TEST);
        glDisable (GL_BLEND);
    }

    glViewport (0, 0, winWidth, winWidth);
    glMatrixMode (GL_PROJECTION);
    glLoadIdentity ();
    gluPerspective (60.0, winWidth/winHeight, 1.0, 500.0);


    /*********************************
        setup the lights
    *********************************/
    glMatrixMode (GL_MODELVIEW);
    glLoadIdentity ();
    glTranslated (camx-MAX_POINTS/4, camy-MAX_POINTS/2, camz-MAX_POINTS);

    // ambient
    glLightfv (GL_LIGHT0, GL_AMBIENT, lightAmbient);
    glLightModelf (GL_LIGHT_MODEL_TWO_SIDE, 1.0f);

    // red
    lightPosition[0] = MAX_POINTS/2; lightPosition[1] = MAX_POINTS/2; lightPosition[2] = MAX_POINTS/2;
    glLightfv (GL_LIGHT0, GL_POSITION, lightPosition);
    glLightfv (GL_LIGHT0, GL_DIFFUSE, lightRed);

    // green
//    lightPosition[0] = MAX_POINTS; lightPosition[1] = MAX_POINTS/2; lightPosition[2] = 2.1f;
    lightPosition[0] = MAX_POINTS/2; lightPosition[1] = MAX_POINTS/2; lightPosition[2] = 2.1f;
    glLightfv (GL_LIGHT1, GL_POSITION, lightPosition);
    glLightfv (GL_LIGHT1, GL_DIFFUSE, lightGreen);

    // blue
    lightPosition[0] = MAX_POINTS/2; lightPosition[1] = MAX_POINTS; lightPosition[2] = 2.1f;
    glLightfv (GL_LIGHT2, GL_POSITION, lightPosition);
    glLightfv (GL_LIGHT2, GL_DIFFUSE, lightBlue);


    numRenderedFrames = 0;
    xrot = yrot = zrot = 0.0;
    camx = -2.5, camy = -2.5, camz = -30.0;
    tickStart = GetTickCount ();
    _openGl_initSquares ();
    
    // reset MIDI
    // NOTE: midiOutReset() does not work, so shut the sound up
    midiMsg = 0;
    if (midiHandle != NULL)
    {
        midiOutClose (midiHandle);
        midiHandle = NULL;
    }
    midiOutOpen (&midiHandle, (unsigned int)-1, 0, 0, CALLBACK_NULL);


    return (0);
}


void
_openGl_initSquares ()
{
    int groupId = 0;
    double i, j, k;
    squareT *s = &squares[0];


    for (i=-STEP; i < STEP; i+=STEP)
    {
        for (j=-STEP; j < STEP; j+=STEP)
        {
            for (k=0; k < 20; k++)
            {
                memset (s, 0, sizeof(squareT));

//                s->x = i; s->y = j; s->z = k;
//                s->x = 3*groupId; s->y = 3*groupId; s->z = 3*groupId;
                s->x = k+i+j; s->y = k+i+j; s->z = k+i+j;

                s->r = s->g = s->b = 0.5;
                s->groupId = groupId;
                s->xrot = s->yrot = s->zrot = drand48 ();

                s->moveClock = 10;
                s->rotationClock = 20;

                s ++;
            }

            groupId ++;
        }
    }
}


void
_openGl_render_squareRoots ()
{
    int i;
    squareT *s;
    double r, fi, delta;
    static boolean firstTime = true;
    static double rxclk, ryclk, rzclk;
    static double txclk, tyclk, tzclk;


    if (firstTime)
    {
        rxclk = drand48 ();
        ryclk = drand48 ();
        rzclk = drand48 ();

        txclk = drand48 ();
        tyclk = drand48 ();
        tzclk = drand48 ();

        firstTime = false;
    }


    glTranslated (camx, camy-10.0, camz-MAX_POINTS/2);
    glRotated (xrot, 1, 0, 0);
    glRotated (yrot, 0, 1, 0);
    glRotated (zrot, 0, 0, 1);
    if (rotateCamera)
    {
        xrot += 0.1; yrot += 0.1; zrot += 0.1;
    }


    if (!clearColorOnRender)
    {
        glEnable (GL_BLEND);
        glDisable (GL_LIGHTING);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4d (0.0, 0.0, 0.0, 0.2);

        glBegin (GL_QUADS);
            glTexCoord2d (0, 1);
            glVertex3d (-50, 50, -20);
            glTexCoord2d (1, 1);
            glVertex3d (50, 50, -20);
            glTexCoord2d (1, 0);
            glVertex3d (50, -50, -20);
            glTexCoord2d (0, 0);
            glVertex3d (-50, -50, -20);
        glEnd ();


        if (lightingEnabled)
        {
            glEnable (GL_LIGHTING);
        }
        if (transparencyEnabled)
        {
            glBlendFunc (GL_SRC_ALPHA, GL_ONE);
        }
        else
        {
            glDisable (GL_BLEND);
        }
    }


    for (i=0; i < NUM_SQUARES; i++)
    {
        s = &squares[i];

#if 0
        r = math_sinGenerator (txclk, 2333, 2, 0, 3);
        fi = math_sinGenerator (tyclk, 138, 4882, -5, (double)(-5+s->groupId+i));
        delta = math_sinGenerator (tzclk, 112, 127, -5, (double)(-3+s->groupId+i));
#else
        r = math_sinGenerator (txclk, 333, 2, 0, 2) +
            math_peakGenerator (rxclk, 1288, 2, -5, 5);
        fi = math_sinGenerator (tyclk, 38, 4882, -5, (double)(-2 + 3*s->groupId)) +
            math_peakGenerator (ryclk, 333, 2, -20, 20);
        delta = math_sinGenerator (tzclk, 22, 127, -5, (double)(-1 + 3*s->groupId)) +
            math_peakGenerator (rzclk, 333, 2, -11, 11);
#endif

//        delta = math_sinGenerator (tzclk, 112, 127, -s->groupId, s->groupId);
        glRotated (r*cos (fi)*cos (delta), 1, 0, 0);
        glRotated (r*cos (fi)*sin (delta), 0, 1, 0);
        glRotated (r*sin (fi), 0, 0, 1);


        glPushMatrix ();
        glTranslated (r*cos (fi)*cos (delta), r*cos (fi)*sin (delta), r*sin (fi));

        txclk += 0.01/SMOOTHNESS;
        tyclk += 0.01/SMOOTHNESS;
        tzclk += 0.01/SMOOTHNESS;


#if 1
        glRotated (math_sinGenerator(rxclk, 1283, 299, -180, 180), 1, 0, 0);
        glRotated (math_sinGenerator(ryclk, 2813, 317, -180, 180), 0, 1, 0);
        glRotated (math_sinGenerator(rzclk, 7009, 599, -180, 180), 0, 0, 1);
#endif


        rxclk += (double)0.1/(100*SMOOTHNESS);
        ryclk += (double)0.1/(100*SMOOTHNESS);
        rzclk += (double)0.1/(100*SMOOTHNESS);


        glPushMatrix ();
//            glTranslated (s->x + s->groupId, s->y, s->z + s->groupId);
            glTranslated (s->x, s->y, s->z);

            glRotated (s->xrot, 1, 0, 0);
            glRotated (s->yrot, 0, 1, 0);
            glRotated (s->zrot, 0, 0, 1);

#if 0
            glRotated (i + r*cos (fi)*cos (delta), 1, 0, 0);
            glRotated (i + r*cos (fi)*sin (delta), 0, 1, 0);
            glRotated (i + r*sin (fi), 0, 0, 1);
#endif
//            glColor3d (s->r, s->g, s->b);
            glColor4d (s->r, s->g, s->b, clearColorOnRender ? 1.0 : 0.2);
            glRectd (0, 0, 1, 1);
            if (drawSquareBorders)
            {
                glColor3d (1.0, 1.0, 1.0);
                glBegin (GL_LINE_LOOP);
                    glVertex3d (0, 0, 0);
                    glVertex3d (0, 1, 0);
                    glVertex3d (1, 1, 0);
                    glVertex3d (1, 0, 0);
                glEnd ();
            }
        glPopMatrix ();

        glPopMatrix ();
    }
}


void
_openGl_render_wishingWell ()
{
    int i;
    squareT *s;
    static double clk = 0.0;
    double dt;


    glTranslated (camx, camy-10.0, camz-MAX_POINTS/2);
    glRotated (xrot, 1, 0, 0);
    glRotated (yrot, 0, 1, 0);
    glRotated (zrot, 0, 0, 1);
    if (rotateCamera)
    {
        xrot += 0.1; yrot += 0.1; zrot += 0.1;
    }


    if (!clearColorOnRender)
    {
        glEnable (GL_BLEND);
        glDisable (GL_LIGHTING);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4d (0.0, 0.0, 0.0, 0.2);

        glBegin (GL_QUADS);
            glTexCoord2d (0, 1);
            glVertex3d (-50, 50, -20);
            glTexCoord2d (1, 1);
            glVertex3d (50, 50, -20);
            glTexCoord2d (1, 0);
            glVertex3d (50, -50, -20);
            glTexCoord2d (0, 0);
            glVertex3d (-50, -50, -20);
        glEnd ();


        if (lightingEnabled)
        {
            glEnable (GL_LIGHTING);
        }
        if (transparencyEnabled)
        {
            glBlendFunc (GL_SRC_ALPHA, GL_ONE);
        }
        else
        {
            glDisable (GL_BLEND);
        }
    }


    dt = 10*cos (math_sinGenerator(clk, 2848, 222, -M_PI, M_PI));
    for (i=0; i < NUM_SQUARES; i++)
    {
        s = &squares[i];

#if 0
        glRotated (math_peakGenerator (clk+i, 1730, 410, 0.0, 90.0) +
                   math_sinGenerator (clk+i, 7500, 300, 5.0, 30.0), 0, 1, 1);
#elif 0
        glRotated (math_sinGenerator (clk, 7500, 3, -10.2, 10.2), 0, 1, 1);
#elif 1
        glRotated (math_peakGenerator (clk, 17300, 410, 5.0, 30.0) +
                   math_sinGenerator (clk, 7500, 300, 5.0, 30.0), 0, 1, 1);
#elif 1
        {
            double f = math_sinGenerator (clk, 17300, 410, 5.0, 30.0);
            glRotated (f/2 + sin(f), 0, 1, 1);
        }
#endif

        glPushMatrix ();
#if 1
            glTranslated (s->x - i/5.0 + dt, s->y + i/6.0, s->z + i/8.0 + dt);
#elif 0
            dt = 10*cos (math_sinGenerator(i+clk, 2480, 222, -M_PI, M_PI));
            glTranslated (s->x - (i+dt)/5.0, s->y + (i+dt)/6.0, s->z + (i+dt)/8.0);
#elif 1
            glTranslated (s->x + dt, s->y + i/5.0, s->z + dt);
#endif

            glRotated (s->xrot, 1, 0, 0);
            glRotated (s->yrot, 0, 1, 0);
            glRotated (s->zrot, 0, 0, 1);

//            glColor3d (s->r, s->g, s->b);
            glColor4d (s->r, s->g, s->b, clearColorOnRender ? 1.0 : 0.2);
            glRectd (0, 0, 1, 1);
            if (drawSquareBorders)
            {
                glColor3d (1.0, 1.0, 1.0);
                glBegin (GL_LINE_LOOP);
                    glVertex3d (0, 0, 0);
                    glVertex3d (0, 1, 0);
                    glVertex3d (1, 1, 0);
                    glVertex3d (1, 0, 0);
                glEnd ();
            }
        glPopMatrix ();

        osc_nextMove (&squares[i], 1);
    }

    osc_nextMove (squares, NUM_SQUARES);
    clk += 100.0/SMOOTHNESS;
}


void
_openGl_render_dancingPolaroids ()
{
    int x = 0;
    double i, j, k, speed, oldTheta;
    static double clk = 0.0, speedClock = 0.0, theta = 0.0, iclock = 0.0;


    if (clk == 0)
    {
        srand (time(NULL));
        clk = (double)(rand () % 1000);
    }
    speedClock += math_sinGenerator (clk, 530, 0, -15.0/SMOOTHNESS, 15.0/SMOOTHNESS)*10;
    speed = math_sinGenerator (speedClock, 2700, 400, -0.1, 0.1);
    theta += speed;
    while (theta > 200*M_PI)
    {
        theta -= 200*M_PI;
    }
    oldTheta = theta;


    glTranslated (camx, camy, camz-MAX_POINTS/2);
//    glTranslated (camx, camy-MAX_POINTS/2, camz-MAX_POINTS);
    glRotated (xrot, 1, 0, 0);
    glRotated (yrot, 0, 1, 0);
    glRotated (zrot, 0, 0, 1);
    if (rotateCamera)
    {
        xrot += 0.1; yrot += 0.1; zrot += 0.1;
    }


    if (!clearColorOnRender)
    {
        glEnable (GL_BLEND);
        glDisable (GL_LIGHTING);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4d (0.0, 0.0, 0.0, 0.2);

        glBegin (GL_QUADS);
            glTexCoord2d (0, 1);
            glVertex3d (-50, 50, -20);
            glTexCoord2d (1, 1);
            glVertex3d (50, 50, -20);
            glTexCoord2d (1, 0);
            glVertex3d (50, -50, -20);
            glTexCoord2d (0, 0);
            glVertex3d (-50, -50, -20);
        glEnd ();


        if (lightingEnabled)
        {
            glEnable (GL_LIGHTING);
        }
        if (transparencyEnabled)
        {
            glBlendFunc (GL_SRC_ALPHA, GL_ONE);
        }
        else
        {
            glDisable (GL_BLEND);
        }
    }


    for (i=-STEP; i < STEP; i+=STEP)
    {
        glPushMatrix ();
// TBD: enable doubleing!
        glRotated (math_sinGenerator(clk, 750, 300, 5.0, 30.0), 0, 1, 0);
//        glRotated (math_sinGenerator(clk, 750, 1300, -300.0, 300.0), 0, 0, 1);

        for (j=-STEP; j < STEP; j+=STEP)
        {
            glPushMatrix ();

            for (k=0; k < 20; k+=2)
            {
                double height, tilt, p, r;


                r = 1 + math_peakGenerator (clk, 590, 42+x, 0, 0.7) -
                        math_peakGenerator (clk, 1310, 541+x, 0, 1) +
                        math_sinGenerator (speedClock, 381, 0, 0, speed);
                p = math_sinGenerator (clk, 180, 3, -i-j-x, i+j+x)/5;
                height = math_peakGenerator (clk, 600, x*5, 0.0, 0.7) *
                         math_sinGenerator (clk, 127, x, 0.0, 1.0) -
                         math_peakGenerator (clk, 999, x, 0.0, 1.0) + x/5;
//                theta *= pow (math_sinGenerator(iclock, 10304, 122, 1.0, 1.005), p);
                theta *= pow (math_sinGenerator(iclock, 10304, 122, 1.0, 1.005), p);
                tilt = math_peakGenerator (clk, 1730, 410, 0.0, 90.0) +
                       math_sinGenerator (clk, 750, 300, 5.0, 30.0);

                x ++;

                glPushMatrix ();
                glTranslated (i+r*cos(theta), j+r*sin(theta), height+k);

//                glRotated (theta*180.0, 0, 0, 1);
                glRotated (theta*180.0/M_PI, 0, 1, 1);
//                glRotated (x*theta, 0, 1, 1);

                glRotated (tilt, 0, 0, 1);
//                glRotated (tilt, 1, 0, 0);

//                glColor3d ((j+k)*0.04, (i+k)*0.03, 1.0-((i+j)*k*0.04));
                glColor4d ((j+k)*0.04, (i+k)*0.03, 1.0-((i+j)*k*0.04), clearColorOnRender ? 1.0 : 0.2);
                glRectd (0, 0, 1, 1);
                glPopMatrix ();
            }
            glPopMatrix ();
        }
        glPopMatrix ();
    }

    iclock += (10.0 / SMOOTHNESS);
    clk += (10.0 / SMOOTHNESS);
    theta = oldTheta;
}


void
_openGl_render_bipolarAttractors ()
{
    int i;
    squareT *s;
    static double clk = 0.0, clrClk = 0.0;
    double r, fi, delta;


    glTranslated (camx, camy-10.0, camz-MAX_POINTS/2);
    glRotated (xrot, 1, 0, 0);
    glRotated (yrot, 0, 1, 0);
    glRotated (zrot, 0, 0, 1);
    if (rotateCamera)
    {
        xrot += 0.1; yrot += 0.1; zrot += 0.1;
    }


    if (!clearColorOnRender)
    {
        glEnable (GL_BLEND);
        glDisable (GL_LIGHTING);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4d (0.0, 0.0, 0.0, 0.2);

        glBegin (GL_QUADS);
            glTexCoord2d (0, 1);
            glVertex3d (-50, 50, -20);
            glTexCoord2d (1, 1);
            glVertex3d (50, 50, -20);
            glTexCoord2d (1, 0);
            glVertex3d (50, -50, -20);
            glTexCoord2d (0, 0);
            glVertex3d (-50, -50, -20);
        glEnd ();


        if (lightingEnabled)
        {
            glEnable (GL_LIGHTING);
        }
        if (transparencyEnabled)
        {
            glBlendFunc (GL_SRC_ALPHA, GL_ONE);
        }
        else
        {
            glDisable (GL_BLEND);
        }
    }


    for (i=0; i < NUM_SQUARES; i++)
    {
        s = &squares[i];


#if 0    // flowers
        r = math_sinGenerator (clk, 2333, 2, 1, i/5.0+1);
        fi = math_sinGenerator (clk, 38, 4882, 0, i/5.0+1);
        delta = math_sinGenerator (clk, 34, 288, 0, i/5.0+1);
#elif 0  // turbulence bubble
        r = math_sinGenerator (clk, 2333, 2, 1, 15);
        fi = math_sinGenerator (clk, 138, 4882, 0, i);
        delta = math_sinGenerator (clk, 134, 288, 0, i);
#elif 0  // fast oscilloscope
        r = math_sinGenerator (clk, 2333, 2, 1, 15);
        fi = math_sinGenerator (clk, 13, 4882, 0, 360);
        delta = math_sinGenerator (clk, 14, 288, 0, 260);
#elif 1  // strange polar attractors?
        r = math_sinGenerator (s->x+clk, 233, 112, 5, 20);
        fi = math_sinGenerator (s->y+clk, 31, 482, 0, M_PI);
        delta = math_sinGenerator (s->z+clk, 114, 2828, 0, M_PI);
#endif

        s->x = r*cos (fi)*cos (delta);
        s->y = r*cos (fi)*sin (delta);
        s->z = r*sin (fi);
        clk += (0.01 / SMOOTHNESS);
        midiMsg += (unsigned long)(s->x + s->y + s->z - delta);

        if (squarePersonality)
        {
            s->x += i/5.0;
            s->y += i/5.0;
            s->z += i/5.0;
        }

        s->r = math_sinGenerator (clrClk, 2, 2, 0.1, 1);
        s->g = math_sinGenerator (clrClk, 3, 2, 0.1, 1);
        s->b = math_sinGenerator (clrClk, 5, 2, 0.1, 1);
        clrClk += (math_sinGenerator(sin(clrClk), 100, i, 0, 1)/10000);

        glPushMatrix ();
            glTranslated (s->x, s->y, s->z);
            glRotated (s->xrot, 1, 0, 0);
            glRotated (s->yrot, 0, 1, 0);
            glRotated (s->zrot, 0, 0, 1);

//            glColor3d (s->r, s->g, s->b);
            glColor4d (s->r, s->g, s->b, clearColorOnRender ? 1.0 : 0.2);
            glRectd (0, 0, 1, 1);
            if (drawSquareBorders)
            {
                glColor3d (1.0, 1.0, 1.0);
                glBegin (GL_LINE_LOOP);
                    glVertex3d (0, 0, 0);
                    glVertex3d (0, 1, 0);
                    glVertex3d (1, 1, 0);
                    glVertex3d (1, 0, 0);
                glEnd ();
            }
        glPopMatrix ();
    }
}


void
_openGl_render_polarFlowers ()
{
    int i;
    squareT *s;
    static double clk = 0.0, clrClk = 0.0;
    double r, fi, delta;


    glTranslated (camx, camy-10.0, camz-MAX_POINTS/2);
    glRotated (xrot, 1, 0, 0);
    glRotated (yrot, 0, 1, 0);
    glRotated (zrot, 0, 0, 1);
    if (rotateCamera)
    {
        xrot += 0.1; yrot += 0.1; zrot += 0.1;
    }


    if (!clearColorOnRender)
    {
        glEnable (GL_BLEND);
        glDisable (GL_LIGHTING);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4d (0.0, 0.0, 0.0, 0.2);

        glBegin (GL_QUADS);
            glTexCoord2d (0, 1);
            glVertex3d (-50, 50, -20);
            glTexCoord2d (1, 1);
            glVertex3d (50, 50, -20);
            glTexCoord2d (1, 0);
            glVertex3d (50, -50, -20);
            glTexCoord2d (0, 0);
            glVertex3d (-50, -50, -20);
        glEnd ();


        if (lightingEnabled)
        {
            glEnable (GL_LIGHTING);
        }
        if (transparencyEnabled)
        {
            glBlendFunc (GL_SRC_ALPHA, GL_ONE);
        }
        else
        {
            glDisable (GL_BLEND);
        }
    }


    for (i=0; i < NUM_SQUARES; i++)
    {
        s = &squares[i];

        r = math_sinGenerator (clk, 2333, 2, 1, i/5.0+1);
        fi = math_sinGenerator (clk, 38, 4882, 0, i/5.0+1);
        delta = math_sinGenerator (clk, 34, 288, 0, i/5.0+1);

        s->x = r*cos (fi)*cos (delta);
        s->y = r*cos (fi)*sin (delta);
        s->z = r*sin (fi);
        clk += (0.01 / SMOOTHNESS);
        midiMsg += (unsigned long)(s->x + s->y + s->z - delta);

        if (squarePersonality)
        {
            s->x += i/5.0;
            s->y += i/5.0;
            s->z += i/5.0;
        }

        s->r = math_sinGenerator (clrClk, 2, 2, 0.1, 1);
        s->g = math_sinGenerator (clrClk, 3, 2, 0.1, 1);
        s->b = math_sinGenerator (clrClk, 5, 2, 0.1, 1);
        clrClk += (math_sinGenerator(sin(clrClk), 100, i, 0, 1)/10000);

        glPushMatrix ();
            glTranslated (s->x, s->y, s->z);
            glRotated (s->xrot, 1, 0, 0);
            glRotated (s->yrot, 0, 1, 0);
            glRotated (s->zrot, 0, 0, 1);

//            glColor3d (s->r, s->g, s->b);
            glColor4d (s->r, s->g, s->b, clearColorOnRender ? 1.0 : 0.2);
            glRectd (0, 0, 1, 1);
            if (drawSquareBorders)
            {
                glColor3d (1.0, 1.0, 1.0);
                glBegin (GL_LINE_LOOP);
                    glVertex3d (0, 0, 0);
                    glVertex3d (0, 1, 0);
                    glVertex3d (1, 1, 0);
                    glVertex3d (1, 0, 0);
                glEnd ();
            }
        glPopMatrix ();
    }
}


void
_openGl_render_turbulenceBubble ()
{
    int i;
    squareT *s;
    static double clk = 0.0, clrClk = 0.0;
    double r, fi, delta;


    glTranslated (camx, camy-10.0, camz-MAX_POINTS/2);
    glRotated (xrot, 1, 0, 0);
    glRotated (yrot, 0, 1, 0);
    glRotated (zrot, 0, 0, 1);
    if (rotateCamera)
    {
        xrot += 0.1; yrot += 0.1; zrot += 0.1;
    }


    if (!clearColorOnRender)
    {
        glEnable (GL_BLEND);
        glDisable (GL_LIGHTING);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4d (0.0, 0.0, 0.0, 0.2);

        glBegin (GL_QUADS);
            glTexCoord2d (0, 1);
            glVertex3d (-50, 50, -20);
            glTexCoord2d (1, 1);
            glVertex3d (50, 50, -20);
            glTexCoord2d (1, 0);
            glVertex3d (50, -50, -20);
            glTexCoord2d (0, 0);
            glVertex3d (-50, -50, -20);
        glEnd ();


        if (lightingEnabled)
        {
            glEnable (GL_LIGHTING);
        }
        if (transparencyEnabled)
        {
            glBlendFunc (GL_SRC_ALPHA, GL_ONE);
        }
        else
        {
            glDisable (GL_BLEND);
        }
    }


    for (i=0; i < NUM_SQUARES; i++)
    {
        s = &squares[i];

        r = math_sinGenerator (clk, 2333, 2, 1, 15);
        fi = math_sinGenerator (clk, 138, 4882, 0, (double)i);
        delta = math_sinGenerator (clk, 134, 288, 0, (double)i);

        s->x = r*cos (fi)*cos (delta);
        s->y = r*cos (fi)*sin (delta);
        s->z = r*sin (fi);
        clk += (0.01 / SMOOTHNESS);
        midiMsg += (unsigned long)(s->x + s->y + s->z - delta);

        if (squarePersonality)
        {
            s->x += i/5.0;
            s->y += i/5.0;
            s->z += i/5.0;
        }

        s->r = math_sinGenerator (clrClk, 2, 2, 0.1, 1);
        s->g = math_sinGenerator (clrClk, 3, 2, 0.1, 1);
        s->b = math_sinGenerator (clrClk, 5, 2, 0.1, 1);
        clrClk += (math_sinGenerator(sin(clrClk), 100, i, 0, 1)/10000);

        glPushMatrix ();
            glTranslated (s->x, s->y, s->z);
            glRotated (s->xrot, 1, 0, 0);
            glRotated (s->yrot, 0, 1, 0);
            glRotated (s->zrot, 0, 0, 1);

            glColor3d (s->r, s->g, s->b);
            glRectd (0, 0, 1, 1);
            if (drawSquareBorders)
            {
//                glColor3d (1.0, 1.0, 1.0);
                glColor4d (1.0, 1.0, 1.0, clearColorOnRender ? 1.0 : 0.2);
                glBegin (GL_LINE_LOOP);
                    glVertex3d (0, 0, 0);
                    glVertex3d (0, 1, 0);
                    glVertex3d (1, 1, 0);
                    glVertex3d (1, 0, 0);
                glEnd ();
            }
        glPopMatrix ();
    }
}


void
_openGl_render_oscilloscope ()
{
    int i;
    squareT *s;
    static double clk = 0.0, clrClk = 0.0;
    double r, fi, delta;


    glTranslated (camx, camy-10.0, camz-MAX_POINTS/2);
    glRotated (xrot, 1, 0, 0);
    glRotated (yrot, 0, 1, 0);
    glRotated (zrot, 0, 0, 1);
    if (rotateCamera)
    {
        xrot += 0.1; yrot += 0.1; zrot += 0.1;
    }


    if (!clearColorOnRender)
    {
        glEnable (GL_BLEND);
        glDisable (GL_LIGHTING);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4d (0.0, 0.0, 0.0, 0.2);

        glBegin (GL_QUADS);
            glTexCoord2d (0, 1);
            glVertex3d (-50, 50, -20);
            glTexCoord2d (1, 1);
            glVertex3d (50, 50, -20);
            glTexCoord2d (1, 0);
            glVertex3d (50, -50, -20);
            glTexCoord2d (0, 0);
            glVertex3d (-50, -50, -20);
        glEnd ();


        if (lightingEnabled)
        {
            glEnable (GL_LIGHTING);
        }
        if (transparencyEnabled)
        {
            glBlendFunc (GL_SRC_ALPHA, GL_ONE);
        }
        else
        {
            glDisable (GL_BLEND);
        }
    }


    for (i=0; i < NUM_SQUARES; i++)
    {
        s = &squares[i];

        r = math_sinGenerator (clk, 2333, 2, 1, 15);
        fi = math_sinGenerator (clk, 13, 4882, 0, 360);
        delta = math_sinGenerator (clk, 14, 288, 0, 260);

        s->x = r*cos (fi)*cos (delta);
        s->y = r*cos (fi)*sin (delta);
        s->z = r*sin (fi);
        clk += (0.01 / SMOOTHNESS);
        midiMsg += (unsigned long)(s->x + s->y + s->z - delta);

        if (squarePersonality)
        {
            s->x += i/5.0;
            s->y += i/5.0;
            s->z += i/5.0;
        }

        s->r = math_sinGenerator (clrClk, 2, 2, 0.1, 1);
        s->g = math_sinGenerator (clrClk, 3, 2, 0.1, 1);
        s->b = math_sinGenerator (clrClk, 5, 2, 0.1, 1);
        clrClk += (math_sinGenerator(sin(clrClk), 100, i, 0, 1)/10000);

        glPushMatrix ();
            glTranslated (s->x, s->y, s->z);
            glRotated (s->xrot, 1, 0, 0);
            glRotated (s->yrot, 0, 1, 0);
            glRotated (s->zrot, 0, 0, 1);

//            glColor3d (s->r, s->g, s->b);
            glColor4d (s->r, s->g, s->b, clearColorOnRender ? 1.0 : 0.2);
            glRectd (0, 0, 1, 1);
            if (drawSquareBorders)
            {
                glColor3d (1.0, 1.0, 1.0);
                glBegin (GL_LINE_LOOP);
                    glVertex3d (0, 0, 0);
                    glVertex3d (0, 1, 0);
                    glVertex3d (1, 1, 0);
                    glVertex3d (1, 0, 0);
                glEnd ();
            }
        glPopMatrix ();
    }
}


void
_openGl_render_brokenMosaic ()
{
    double i, j, k, r, fi, delta;
    static double clk = 0, iclk = 0;


    if (clk == 0)
    {
        srand (time(NULL));
        clk = drand48 ();
        iclk = drand48 ();
    }


    glTranslated (camx, camy-MAX_POINTS/8, camz-MAX_POINTS/2);
    glRotated (xrot, 1, 0, 0);
    glRotated (yrot, 0, 1, 0);
    glRotated (zrot, 0, 0, 1);
    if (rotateCamera)
    {
        xrot += 0.1; yrot += 0.1; zrot += 0.1;
    }


    if (!clearColorOnRender)
    {
        glEnable (GL_BLEND);
        glDisable (GL_LIGHTING);
        glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4d (0.0, 0.0, 0.0, 0.2);

        glBegin (GL_QUADS);
            glTexCoord2d (0, 1);
            glVertex3d (-50, 50, -20);
            glTexCoord2d (1, 1);
            glVertex3d (50, 50, -20);
            glTexCoord2d (1, 0);
            glVertex3d (50, -50, -20);
            glTexCoord2d (0, 0);
            glVertex3d (-50, -50, -20);
        glEnd ();


        if (lightingEnabled)
        {
            glEnable (GL_LIGHTING);
        }
        if (transparencyEnabled)
        {
            glBlendFunc (GL_SRC_ALPHA, GL_ONE);
        }
        else
        {
            glDisable (GL_BLEND);
        }
    }


    for (i=-STEP; i < STEP; i+=STEP)
    {
        glPushMatrix ();

        for (j=-STEP; j < STEP; j+=STEP)
        {
            r = math_sinGenerator (iclk, 23, 127, 1, 50);
            fi = math_sinGenerator (iclk, 38, 282, 0, 2*M_PI);
            delta = math_sinGenerator (iclk, 34, 1857, 0, 2*M_PI);
            iclk += 0.1/SMOOTHNESS;

            glPushMatrix ();
            glRotated (r*cos(fi)*cos(delta), 1, 0, 0);
            glRotated (r*cos(fi)*sin(delta), 0, 1, 0);
            glRotated (r*sin(fi), 0, 0, 1);

            for (k=0; k < 20; k+=2)
            {
                double theta = math_sinGenerator (clk, 392, 138, 0, 2*M_PI);


                r = math_sinGenerator (clk, 233, 2, 1, 15);
                fi = math_sinGenerator (clk, 38, 4882, 0, k+i+j);
                delta = math_sinGenerator (clk, 34, 288, 0, k+i+j);
                clk += (0.01 / SMOOTHNESS);

                glRotated (theta, 0, 0, 1);

                glPushMatrix ();
                glRotated (theta, 1, 0, 0);
                glTranslated (r*cos(fi)*cos(delta), r*cos(fi)*sin(delta), r*sin(fi)+k/3);

//                glColor3d ((j+k)*0.04, (i+k)*0.03, 1.0-((i+j)*k*0.04));
                glColor4d ((j+k)*0.04, (i+k)*0.03, 1.0-((i+j)*k*0.04), clearColorOnRender ? 1.0 : 0.2);
                glRectd (0, 0, 1, 1);
                if (drawSquareBorders)
                {
//                    glColor3d (1.0, 1.0, 1.0);
                    glColor4d (1.0, 1.0, 1.0, clearColorOnRender ? 1.0 : 0.2);
                    glBegin (GL_LINE_LOOP);
                        glVertex3d (0, 0, 0);
                        glVertex3d (0, 1, 0);
                        glVertex3d (1, 1, 0);
                        glVertex3d (1, 0, 0);
                    glEnd ();
                }
                glPopMatrix ();
            }

            glPopMatrix ();
        }

        glPopMatrix ();
    }
}


void
openGl_render ()
{
    glClear (GL_DEPTH_BUFFER_BIT | (clearColorOnRender ? GL_COLOR_BUFFER_BIT : 0));

    glMatrixMode (GL_MODELVIEW);
    glLoadIdentity ();

    renderFunction ();
    numRenderedFrames ++;

    if (soundEnabled && midiHandle != NULL)
    {
        midiOutShortMsg (midiHandle, midiMsg);
    }
}


#if 0
____________________________ Main functions ____________________________
() {}
#endif
#define STRONOFF(_condition) ((_condition) ? "on" : "off")
void
info_show (double fps)
{
    char str[256];
    int i, blendSrc, blendDst;
    double y = 0.400;


    glPushAttrib (0xffffffff);
    glDisable (GL_TEXTURE_2D);
    glDisable (GL_BLEND);
    glDisable (GL_LIGHTING);
    glDisable (GL_DEPTH_TEST);

    glGetIntegerv (GL_BLEND_SRC, &blendSrc);
    glGetIntegerv (GL_BLEND_DST, &blendDst);

    glMatrixMode (GL_MODELVIEW);
    glPushMatrix ();
    glLoadIdentity ();
    glMatrixMode (GL_PROJECTION);
    glPushMatrix ();
    glLoadIdentity ();
    gluOrtho2D (0, 0, winWidth, winHeight);

    glListBase (fontBase - 32);


    /**************************************
        draw the text
    **************************************/
    glColor3d (0.25, 0.75, 1.0);

    strcpy (str, "Help:");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.025;

    strcpy (str, "------------------------------");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.025;

    strcpy (str, "F1 - show help screen");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    strcpy (str, "ESC - exit");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    sprintf (str, "F - fullscreen (%s)", STRONOFF(!windowMode));
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    sprintf (str, "L - lighting (%s)", STRONOFF(lightingEnabled));
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    sprintf (str, "T - transparency (%s)", STRONOFF(transparencyEnabled));
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    sprintf (str, "C - clear color buffer (%s)", STRONOFF(clearColorOnRender));
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    sprintf (str, "P - square personality (%s)", STRONOFF(squarePersonality));
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    sprintf (str, "B - square borders (%s)", STRONOFF(drawSquareBorders));
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    sprintf (str, "M - rotate camera (%s)", STRONOFF(rotateCamera));
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    strcpy (str, "R - reset camera");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    sprintf (str, "S - sound (%s)", STRONOFF(soundEnabled));
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.105;


    strcpy (str, "Info:");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.025;

    strcpy (str, "------------------------------");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.025;

    sprintf (str, "FPS: %2.2lf", fps);
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    sprintf (str, "pos: %2.2lf,%2.2lf,%2.2lf", camx, camy, camz);
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    sprintf (str, "rot: %2.2lf,%2.2lf,%2.2lf", xrot, yrot, zrot);
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.105;


    strcpy (str, "Screensavers:");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.025;

    strcpy (str, "------------------------------");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.025;

    for (i=0; ; i++)
    {
        if (glectricModules[i].function == NULL)
        {
            break;
        }

        sprintf (str, "%c - %s", glectricModules[i].key, glectricModules[i].description);

        if (glectricModules[i].function == renderFunction)
        {
            glColor3d (1.0, 0.15, 0.15);
        }
        glRasterPos2d (-0.985, y);
        glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
        y -= 0.035;

        if (glectricModules[i].function == renderFunction)
        {
            glColor3d (0.25, 0.75, 1.0);
        }
    }
    y -= 0.035;

    strcpy (str, "* - has square personality");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);
    y -= 0.035;

    strcpy (str, "+ - has sound");
    glRasterPos2d (-0.985, y);
    glCallLists (strlen(str), GL_UNSIGNED_BYTE, str);




    /**************************************
        and the transparent rectangle
    **************************************/
    glEnable (GL_BLEND);
    glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4d (0.25, 0.75, 1.0, 0.10);
    glTranslated (-1.0, -1.0, 0.0);
    glRectd (0.0, -0.01, 0.6, 2.0);


    glPopMatrix ();
    glMatrixMode (GL_MODELVIEW);
    glPopMatrix ();

    glPopAttrib ();

    glBlendFunc (blendSrc, blendDst);
}


void
mouse_move (double x, double y, double z)
{
    if (x != 0)
    {
        camx += (x-mousex)/10.0;
        mousex = x;
    }

    if (y != 0)
    {
        camy -= (y-mousey)/10.0;
        mousey = y;
    }

    if (z != 0)
    {
        camz -= (z-mousez)/10.0;
        mousez = z;
    }
}


void
mouse_rotate (double x, double y, double z)
{
    if (x != 0)
    {
        xrot += (x-mousex)/2.0;
        if (xrot >= 360.0)
        {
            xrot -= 360.0;
        }
        else if (xrot < 0.0)
        {
            xrot += 360.0;
        }
        mousex = x;
    }

    if (y != 0)
    {
        yrot -= (y-mousey)/2.0;
        if (yrot >= 360.0)
        {
            yrot -= 360.0;
        }
        else if (yrot < 0.0)
        {
            yrot += 360.0;
        }
        mousey = y;
    }

    if (z != 0)
    {
        zrot -= (z-mousez)/2.0;
        if (zrot >= 360.0)
        {
            zrot -= 360.0;
        }
        else if (zrot < 0.0)
        {
            zrot += 360.0;
        }
        mousez = z;
    }
}


LRESULT CALLBACK
WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int i;
    POINT p;


    switch (message)
    {
        case WM_CREATE:
        case WM_DESTROY:
            return (0);

        case WM_CLOSE:
            PostQuitMessage (0);
            return (0);

        case WM_LBUTTONDOWN:
        case WM_RBUTTONDOWN:
            /* remember the mouse position when button pressed */
            GetCursorPos (&p);
            mousex = (double)p.x;
            mousey = (double)p.y;
            return (0);

        case WM_MOUSEWHEEL:
            /* move forward/backward */
            camz += (double)((short)HIWORD (wParam))/10.0;
            return (0);

        case WM_MOUSEMOVE:
            if (wParam & MK_LBUTTON)
            {
                if (wParam & MK_CONTROL)
                {
                    /* move forward/backward */
                    mouse_move (0, 0, (double)GET_Y_LPARAM (lParam));
                }
                else
                {
                    /* move left/right and up/down */
                    mouse_move ((double)GET_X_LPARAM (lParam), (double)GET_Y_LPARAM (lParam), 0);
                }
            }
            else if (wParam & MK_RBUTTON)
            {
                if (wParam & MK_CONTROL)
                {
                    /* rotate forward/backward */
                    mouse_rotate (0, 0, (double)GET_Y_LPARAM (lParam));
                }
                else
                {
                    /* rotate left/right and up/down */
                    mouse_rotate ((double)GET_Y_LPARAM (lParam), (double)GET_X_LPARAM (lParam), 0);
                }
            }
            return (0);

        case WM_KEYUP:
            if (wParam == VK_ESCAPE)
            {
                PostQuitMessage (0);
            }
            else if (wParam == VK_F1)
            {
                showInfo = !showInfo;
            }
            else if (wParam == 'f' || wParam == 'F')
            {
                windowMode = !windowMode;
                openGl_fullscreen (!windowMode);
            }
            else if (wParam == 'b' || wParam == 'B')
            {
                drawSquareBorders = !drawSquareBorders;
            }
            else if (wParam == 'p' || wParam == 'P')
            {
                squarePersonality = !squarePersonality;
            }
            else if (wParam == 'm' || wParam == 'M')
            {
                rotateCamera = !rotateCamera;
            }
            else if (wParam == 'c' || wParam == 'C')
            {
                clearColorOnRender = !clearColorOnRender;
            }
            else if (wParam == 'l' || wParam == 'L')
            {
                lightingEnabled = !lightingEnabled;
                if (lightingEnabled)
                {
                    glEnable (GL_LIGHTING);
                }
                else
                {
                    glDisable (GL_LIGHTING);
                }
            }
            else if (wParam == 'r' || wParam == 'R')
            {
                xrot = yrot = zrot = 0.0;
            }
            else if (wParam == 's' || wParam == 'S')
            {
                soundEnabled = !soundEnabled;
                if (midiHandle != NULL)
                {
                    midiOutClose (midiHandle);
                    midiHandle = NULL;
                }
                midiOutOpen (&midiHandle, (unsigned int)-1, 0, 0, CALLBACK_NULL);
            }
            else if (wParam == 't' || wParam == 'T')
            {
                transparencyEnabled = !transparencyEnabled;
                if (transparencyEnabled)
                {
                    glDisable (GL_DEPTH_TEST);
                    glBlendFunc (GL_SRC_ALPHA, GL_ONE);
                    glEnable (GL_BLEND);
                }
                else
                {
                    glEnable (GL_DEPTH_TEST);
                    glDisable (GL_BLEND);
                }
            }
            else
            {
                for (i=0; glectricModules[i].function != NULL; i++)
                {
                    if (glectricModules[i].key == (char)wParam)
                    {
                        renderFunction = glectricModules[i].function;
                        openGl_setupScene ();    // reset stuph
                        break;
                    }
                }
            }
            return (0);

        default:
            return (DefWindowProc(hWnd, message, wParam, lParam));
    }
}


int APIENTRY
WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, char *cmdLine, int nnn)
{
    int i, ret = 0;
    WNDCLASS wc;
    HDC hDC;
    HGLRC hRC;
    MSG msg;


    // if there's something in cmdLine, we're started with
    // screensaver parameters, such as "Preview" or "Configure Dialog"
    // if it's "/S" it's normal start, otherwise don't start the app!
    if (cmdLine != NULL && cmdLine[0] != '\0' &&
        strstr(cmdLine, "/S") == NULL && strstr(cmdLine, "/s") == NULL && strstr(cmdLine, "-win") == NULL)
    {
        return (0);
    }


#if GLSAVER_DEVEL
    windowMode = true;
#else
    windowMode = (strstr(cmdLine, "-win") != NULL);
#endif

    if (!windowMode)
    {
        // get root window size
        i = GetSystemMetrics (SM_CXSCREEN);
        if (i != 0)
        {
            winWidth = i;
        }
        i = GetSystemMetrics (SM_CYSCREEN);
        if (i != 0)
        {
            winHeight = i;
        }
    }


    // register window class
    wc.style = CS_OWNDC;
    wc.lpfnWndProc = WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor (NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject (BLACK_BRUSH);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = "GLectric";
    RegisterClass (&wc);


    // create main window
    hWnd = CreateWindow ("GLectric", "GLectric",
        WS_POPUPWINDOW | WS_VISIBLE | (windowMode ? WS_CAPTION : 0),
        0, 0, winWidth, winHeight, NULL, NULL, hInstance, NULL);
    FCN_EXIT (hWnd == NULL, -1, {});


    if (!windowMode)
    {
        ShowCursor (FALSE);
    }


    // setup MIDI
    midiHandle = NULL; // main setup is done in openGl_setupScene ()

    // init OpenGL
    openGl_init (hWnd, &hDC, &hRC);

    // setup the needed OpenGL stuph
    openGl_setupScene ();


    //
    // the main engine loop
    //
    while (1)
    {
        // check for messages
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            // handle or dispatch messages
            if (msg.message == WM_QUIT)
            {
                break;
            }
            else
            {
                TranslateMessage (&msg);
                DispatchMessage (&msg);
            }
        }
        else
        {
            // render!
            openGl_render ();

            if (showInfo)
            {
                info_show (numRenderedFrames/((GetTickCount() - tickStart)/1000.0));
            }

            SwapBuffers (hDC);
        }
    }


exit:
    if (midiHandle != NULL)
    {
        midiOutClose (midiHandle);
    }
    openGl_cleanup (hWnd, hDC, hRC);
    DestroyWindow (hWnd);
    return (ret);
}


