IGL is an Open Source port of IrisGL library to OpenGL (Win32/X11)
Current version is 0.1.8.

For information on compiling, installing etc., browse the 'docs' directory.
Licensing information is contained in 'license.txt'.

Additional information, bug reports, suggestions:
email: matevzb@email.si
URL: http://users.volja.net/wesley/igl.html

Hope you like using it, as much as I did coding...
Matevz Bradac

