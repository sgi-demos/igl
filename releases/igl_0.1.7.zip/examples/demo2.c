#include "igl.h"


#define MAX_POINTS 50
#define USE_LIGHTING    0       /* define to 1 to see lighting in pseudo-action */


float xrot, yrot, zrot;
float camx, camy, camz;
double angle, sf[MAX_POINTS], cf[MAX_POINTS];
float clearColor[] = {0.0f, 0.0f, 0.0f};
float normalColor[] = {0.0f, 0.5f, 1.0f};


void
render ()
{
    int i;


    pushmatrix ();
    translate (camx+MAX_POINTS/8, camy+MAX_POINTS/4, camz-MAX_POINTS);
    rot (xrot, 'x');
    rot (yrot, 'y');
    rot (zrot, 'z');
    xrot += 0.5f; yrot += 0.5f; zrot += 0.5f;

    c3f (normalColor);
    for (i=0; i < MAX_POINTS; i++)
    {
        sf[i] += sin (angle*M_PI);
        cf[i] += cos (angle*M_PI);

        rot ((float)(sf[i] - cf[i]), 'x');
        rot ((float)(sf[i] + cf[i]), 'y');
        rot ((float)(sf[i] - cf[i]), 'z');
        angle += 0.00000005;

        pushmatrix ();
            translate ((float)i, 0, 0);
            rectf (0, 0, 1, 1);
        popmatrix ();
    }
    popmatrix ();
}


int
main ()
{
    int n, newn, windowId;
    float t;
#if USE_LIGHTING
    float mat[] =
    {
        AMBIENT, 0.2f, 0.2f, 0.2f,
        DIFFUSE, 0.8f, 0.8f, 0.8f,
        SPECULAR, 0.9f, 0.9f, 0.9f,
        SHININESS, 50.0f,
        LMNULL
    };

    float light1[] =
    {
        AMBIENT, 1.0f, 0.0f, 0.5f,
        POSITION, -3.0f, -3.0f, -80.0f, 0.0f,
        LMNULL
    };

    float light2[] =
    {
        AMBIENT, 0.0f, 0.0f, 1.0f,
        POSITION, 5.0f, 12.0f, -80.0f, 0.0f,
        LMNULL
    };

    float lmodel[] =
    {
        LOCALVIEWER, 1.0f,
        TWOSIDE, 1.0f,
        LMNULL
    };
#endif


    xrot = yrot = zrot = 0;
    camx = -2.5f, camy = -2.5f, camz = -30.0f;


    prefsize (1024, 768);
    windowId = winopen ("demo2");
    winconstraints ();
    doublebuffer ();
    RGBmode ();
    gconfig ();
    perspective (60, 1, 0, 500);
    cursoff ();


#if USE_LIGHTING
    lmdef (DEFMATERIAL, 1, 0, mat);
    lmdef (DEFLIGHT, 1, 0, light1);
    lmdef (DEFLIGHT, 2, 0, light2);
    lmdef (DEFLMODEL, 1, 0, lmodel);
    lmbind (BACKMATERIAL, 1);
    lmbind (LIGHT1, 1);
    lmbind (LIGHT2, 2);
    lmbind (LMODEL, 1);
#endif

    n = 0;
    t = 0.0f;

    /* enable transparency */
    zbuffer (FALSE);
    blendfunction (BF_SA, BF_ONE);

    while (1)
    {
        IGL_MSG_BEGIN

        t += 0.1f;
        newn = (t >= 1.0f);
        n += (int)floor (t);
        t = (float)fmod (t, 1.0f);
        sf[n % MAX_POINTS] += sin (angle*M_PI);
        cf[n % MAX_POINTS] += cos (angle*M_PI);

        c3f (clearColor);
        clear ();

        render ();
        swapbuffers ();

        IGL_MSG_END
    }

    curson ();

    return (0);
}



