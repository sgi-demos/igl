#ifndef IGLCMN_H
#define IGLCMN_H


#include <GL/glu.h> /* for GLUnurbsObj */



#ifdef __cplusplus
extern "C" {
#endif

#define FCN_EXIT(condition_, ret_, action_) \
{                                           \
    if (condition_)                         \
    {                                       \
        ret = ret_;                         \
        action_;                            \
        goto exit;                          \
    }                                       \
}


/*******************************************
    igl_windowT
********************************************/
#define IGL_WFLAGS_NONE             0x00
#define IGL_WFLAGS_FULLSCREEN       0x01
#define IGL_WFLAGS_DOUBLEBUFFER     0x02
#define IGL_WFLAGS_RGBA             0x04
#define IGL_WFLAGS_STEREOBUFFER     0x08
#define IGL_WFLAGS_NOBORDER         0x10

#define IGL_WLAYER_NORMALDRAW       0
#define IGL_WLAYER_UNDERDRAW        1
#define IGL_WLAYER_OVERDRAW         2
#define IGL_WLAYER_PUPDRAW          3
#define IGL_WLAYER_CURSORDRAW       4
#define IGL_WLAYER_MARKER           (IGL_WLAYER_CURSORDRAW+1)
typedef struct
{
    HWND wnd;
    HWND parentWnd;
    HDC hdc;
    HGLRC hrcs[IGL_WLAYER_MARKER];
    short currentLayer;

    char title[256];
    int x, y;
    int width, height;
    int offsetX, offsetY;
    int minWidth, minHeight;
    int maxWidth, maxHeight;
    int aspectX, aspectY;

    /* graphics position related */
    float gposx, gposy, gposz, gposw;

    /* character position related */
    float cposx, cposy, cposz;

    long flags;         /* IGL_WFLAGS_XXX */
    long newFlags;      /* IGL_WFLAGS_XXX before gconfig() */
    long style;         /* window style before fullscrn() */

    /* text/font related */
    unsigned int fontBase;

    /* gconfig() related */
    unsigned char acPlanes;      /* accumulation buffer planes */
    unsigned char stenPlanes;    /* stencil buffer planes */
    unsigned char msPlanes;      /* multisample buffer planes */
    unsigned char zbPlanes;      /* Z-buffer buffer planes */
    unsigned char rgbPlanes;     /* RGB planes */
} igl_windowT;


/*******************************************
    lmdefs
********************************************/
#define IGL_LMMATERIALFLAGS_NONE            0x00
#define IGL_LMMATERIALFLAGS_AMBIENT         0x01
#define IGL_LMMATERIALFLAGS_COLORINDEXES    0x02
#define IGL_LMMATERIALFLAGS_DIFFUSE         0x04
#define IGL_LMMATERIALFLAGS_EMISSION        0x08
#define IGL_LMMATERIALFLAGS_SHININESS       0x10
#define IGL_LMMATERIALFLAGS_SPECULAR        0x20
typedef struct
{
    unsigned short flags;
    float ambient[4];
    float colorIndexes[4];
    float diffuse[4];
    float emission[4];
    float shininess;
    float specular[4];
} igl_lmMaterialDefT;

#define IGL_LMLIGHTFLAGS_NONE           0x00
#define IGL_LMLIGHTFLAGS_AMBIENT        0x01
#define IGL_LMLIGHTFLAGS_LCOLOR         0x02
#define IGL_LMLIGHTFLAGS_POSITION       0x04
#define IGL_LMLIGHTFLAGS_SPOTDIRECTION  0x08
#define IGL_LMLIGHTFLAGS_SPOTLIGHT      0x10
typedef struct
{
    unsigned short flags;
    float ambient[4];
    float lcolor[4];
    float position[4];
    float spotDirection[4];
    float spotLight[2];
} igl_lmLightDefT;

#define IGL_LMMODELFLAGS_NONE           0x00
#define IGL_LMMODELFLAGS_AMBIENT        0x01
#define IGL_LMMODELFLAGS_ATTENUATION    0x02
#define IGL_LMMODELFLAGS_ATTENUATION2   0x04
#define IGL_LMMODELFLAGS_LOCALVIEWER    0x08
#define IGL_LMMODELFLAGS_TWOSIDE        0x10
typedef struct
{
    unsigned short flags;
    float ambient[4];
    float attenuation[2];
    float attenuation2;
    float localViewer;
    float twoSide;
} igl_lmLmodelDefT;


typedef struct
{
    int tvMode;           /* TV_XXX mode */
    float blendColor[4];    /* TV_COLOR specifies it, used with TV_BLEND */
    float component;
} igl_tevDefT;


#define IGL_TEXDEFFLAGS_NONE            0x0000
#define IGL_TEXDEFFLAGS_MINFILTER       0x0001
#define IGL_TEXDEFFLAGS_MAGFILTER       0x0002
#define IGL_TEXDEFFLAGS_MAGFILTERALPHA  0x0004
#define IGL_TEXDEFFLAGS_MAGFILTERCOLOR  0x0008
#define IGL_TEXDEFFLAGS_WRAPS           0x0010
#define IGL_TEXDEFFLAGS_WRAPT           0x0020
#define IGL_TEXDEFFLAGS_WRAPR           0x0040
#define IGL_TEXDEFFLAGS_INTERNALFORMAT  0x0080
#define IGL_TEXDEFFLAGS_EXTERNALFORMAT  0x0100
#define IGL_TEXDEFFLAGS_MIPMAPFILTER    0x0200
#define IGL_TEXDEFFLAGS_CONTROLPOINT    0x0400  /* LOD and scale */
#define IGL_TEXDEFFLAGS_CLAMP           0x0800
#define IGL_TEXDEFFLAGS_DETAIL          0x1000
#define IGL_TEXDEFFLAGS_TILE            0x2000
#define IGL_TEXDEFFLAGS_BICUBICFILTER   0x4000
typedef struct
{
    short numComponents;
    long width;
    long height;
    long depth;
    unsigned short flags;
    float minFilter;
    float magFilter;
    float magFilterAlpha;
    float magFilterColor;
    float wrap;
    float wrapS;
    float wrapT;
    float wrapR;
    float internalFormat;
    float externalFormat;
    float mipmapFilter[8];
    float lod;
    float scale;
    float clamp;
    float detail[5];
    float tile[4];
    float bicubicFilter[2];
    unsigned long *image;
} igl_texDefT;


typedef struct
{
    char title[256];
    short id;
    short delimiter;
    short dontExecuteRoutine;
    int (*routine)(int, ...);
    long submenu;
} igl_menuItemT;

#define IGL_MAXMENUITEMS    100
typedef struct
{
    HMENU hmenu;
    char title[256];
    int (*routine)(int, ...);
    igl_menuItemT items[IGL_MAXMENUITEMS];
} igl_menuT;



/*******************************************
    igl_globalsT
********************************************/
#define IGL_MAXWINDOWS          256         /* max open windows per process */
#define IGL_WINDOWWIDTH         640         /* default window width for winopen() */
#define IGL_WINDOWHEIGHT        480         /* default window height for winopen() */
#define IGL_MAXCOLORS           4096        /* max colors available for color[f]() palette */
#define IGL_MAXLINESTYLES       32          /* max linestyles available */
#define IGL_MAXPOLYVERTICES     256         /* max vertices in a polygon */
#define IGL_MAXCURVESEGMENTS    256         /* max curve segments for crv() and crvn() */
#define IGL_MAXLMDEFS           MAXLIGHTS   /* IrisGL had this many lights */
#define IGL_MAXDEVICES          548         /* max devices on IrisGL - the last one is VIDEO */
#define IGL_MAXDEVQENTRIES      101         /* max entries in device queue */
#define IGL_MAXTIEDVALUATORS    IGL_MAXDEVICES /* max tie()'d valuators */
#define IGL_MAXTEVDEFS          10          /* max tevdef()'s */
#define IGL_MAXTEXDEFS          10          /* max texdef()'s */
#define IGL_MAXMENUS            20
typedef struct
{
    /* app related */
    HINSTANCE appInstance;  /* set by WinMain() on Win32, set by XOpenDisplay() on UNIX */
    int initialized;        /* since some things cannot be inited before WGL, we have a helper */
#if PLATFORM_X11
    XVisualInfo visualInfo;
#endif

    /* window related */
    igl_windowT openWindows[IGL_MAXWINDOWS];
    int currentWindow;
    int winPosx, winPosy;
    int winWidth, winHeight;
    int winMinWidth, winMinHeight;
    int winMaxWidth, winMaxHeight;
    long windowFlags; /* IGL_WFLAGS_NOBORDER - reset on winopen() */

    /* color related */
    unsigned long colorPalette[IGL_MAXCOLORS];
    unsigned short colorIndex;

    /* vertex related */
    Linestyle lineStyles[IGL_MAXLINESTYLES];
    short lineStyleIndex;
    GLUnurbsObj *nurbsCurve;
    short curveSegments;

    /* matrix related */
    short matrixMode;

    /* light related */
    igl_lmMaterialDefT materialDefs[IGL_MAXLMDEFS];
    igl_lmLightDefT lightDefs[IGL_MAXLMDEFS];
    igl_lmLmodelDefT lmodelDefs[IGL_MAXLMDEFS];

    /* device related */
    long devices[IGL_MAXDEVICES];               /* list of devices */
    short deviceQueue[IGL_MAXDEVICES];          /* list of queued devices */
    short eventQueue[IGL_MAXDEVQENTRIES*2];     /* list of queued events */
    int numQueuedEvents;
    Device tiedValuators[IGL_MAXTIEDVALUATORS*2];
    int numTiedValuators;

    /* texture related */
    igl_tevDefT tevDefs[IGL_MAXTEVDEFS];
    igl_texDefT texDefs[IGL_MAXTEXDEFS];

    /* menu related */
    igl_menuT menus[IGL_MAXMENUS];
} igl_globalsT;

extern igl_globalsT *igl;


#if PLATFORM_WIN32
#   define IGL_NULLWND      NULL
#   define IGL_NULLMENU     NULL
#else
#   define IGL_NULLWND      0
#   define IGL_NULLMENU     0
#endif
#define IGL_CHECKINIT(_ret)                                                                     \
{                                                                                               \
    if (igl->currentWindow == -1 || igl->openWindows[igl->currentWindow].wnd == IGL_NULLWND)    \
    {                                                                                           \
        return (_ret);                                                                          \
    }                                                                                           \
}
#define IGL_CHECKINITV()                                                                        \
{                                                                                               \
    if (igl->currentWindow == -1 || igl->openWindows[igl->currentWindow].wnd == IGL_NULLWND)    \
    {                                                                                           \
        return;                                                                                 \
    }                                                                                           \
}


/* returns current window context (igl_windowT *) */
#define IGL_CTX() (&igl->openWindows[igl->currentWindow])

/* returns current HRC of current window */
#define IGL_HRC(_wptr) (_wptr->hrcs[_wptr->currentLayer])

/* references current window's graphical position (gpos)/character position (cpos) */
#define IGL_GPOS(_n) (igl->openWindows[igl->currentWindow].gpos##_n)
#define IGL_CPOS(_n) (igl->openWindows[igl->currentWindow].cpos##_n)


#if PLATFORM_X11
#   define RGB(r,g,b) ((unsigned long)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16)))
#   define GetRValue(_rgb) ((BYTE)(_rgb))
#   define GetGValue(_rgb) ((BYTE)(((WORD)(_rgb)) >> 8))
#   define GetBValue(_rgb) ((BYTE)((_rgb) >> 16))
#endif
/* Win32 API programmers forgot this - get alpha value from an unsigned long */
#define GetAValue(_rgb) ((BYTE)(((WORD)(_rgb)) >> 24))


/* these are needed for gsync() i guess */
typedef BOOL (*WGLSWAPINTERVALEXT) (int interval);
typedef int (*WGLGETSWAPINTERVALEXT) ();

WGLSWAPINTERVALEXT wglSwapIntervalEXT;
WGLGETSWAPINTERVALEXT wglGetSwapIntervalEXT;

#ifdef __cplusplus
}
#endif

#endif  /* IGLCMN_H */


