#include "igl.h"
#include "iglcmn.h"



/* globals */
igl_globalsT *igl;

extern int
main (int argc, char **argv);


#if PLATFORM_WIN32
#if 0
____________________________ WIN32 common stuph ____________________________
() {}
#endif
int APIENTRY
WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, char *cmdLine, int windowState)
{
    int i, j, ret = 0;
    DEVMODE devMode;


    /***************************************
        init (TBD: move to greset())!!!
    ****************************************/
    igl = (igl_globalsT *)malloc (sizeof(igl_globalsT));
    FCN_EXIT (igl == NULL, -1,
        {
            /* TBD: error report */
        });

    /* app-related */
    memset (igl, 0, sizeof(igl_globalsT));
    igl->appInstance = hInstance;
    /* window-related */
    igl->currentWindow = -1;
    igl->winWidth = IGL_WINDOWWIDTH;
    igl->winHeight = IGL_WINDOWHEIGHT;
    /* color-related */
    igl->colorPalette[BLACK] = RGB (0, 0, 0);
    igl->colorPalette[RED] = RGB (255, 0, 0);
    igl->colorPalette[GREEN] = RGB (0, 255, 0);
    igl->colorPalette[YELLOW] = RGB (255, 255, 0);
    igl->colorPalette[BLUE] = RGB (0, 0, 255);
    igl->colorPalette[MAGENTA] = RGB (255, 0, 255);
    igl->colorPalette[CYAN] = RGB (0, 255, 255);
    igl->colorPalette[WHITE] = RGB (255, 255, 255);
    /* vertex-related */
    igl->curveSegments = 30;
    /* matrix-related */
    igl->matrixMode = MSINGLE;
    /* light-related */
    {
        igl_lmMaterialDefT *matPtr = &igl->materialDefs[0];
        igl_lmLightDefT *lightPtr = &igl->lightDefs[0];
        igl_lmLmodelDefT *lmPtr = &igl->lmodelDefs[0];


        matPtr->ambient[0] = matPtr->ambient[1] = matPtr->ambient[2] = 0.2f;
        matPtr->ambient[3] = 1.0f;
        matPtr->diffuse[0] = matPtr->diffuse[1] = matPtr->diffuse[2] = 0.8f;
        matPtr->diffuse[3] = 1.0f;
        matPtr->specular[3] = 1.0f;
        matPtr->emission[3] = 1.0f;

        lightPtr->ambient[3] = 1.0f;
        lightPtr->position[2] = 1.0f;
        lightPtr->spotDirection[2] = -1.0f;
        lightPtr->spotLight[1] = 180.0f;

        lmPtr->ambient[0] = lmPtr->ambient[1] = lmPtr->ambient[2] = 0.2f;
        lmPtr->ambient[3] = 1.0f;
        lmPtr->attenuation[0] = 1.0f;
    }
    /* texture-related */
    igl->tevDefs[0].tvMode = GL_MODULATE;


    /***************************************
        process
    ****************************************/
    /* TBD: parse cmdline to argc && argv */
    /* td->argc = ...; td->argv = ...; */
    ret = main (0, NULL);


    /***************************************
        cleanup
    ****************************************/
exit:
    /* close fullscreen mode */
    memset (&devMode, 0, sizeof(DEVMODE));
    devMode.dmSize = sizeof (DEVMODE);
    ChangeDisplaySettings (&devMode, 0);

    /* cleanup && destroy all menus */
    for (i=0; i < IGL_MAXMENUS; i++)
    {
        if (igl->menus[i].hmenu != NULL)
        {
            DestroyMenu (igl->menus[i].hmenu);
        }
    }

    /* release wgl */
    wglMakeCurrent (NULL, NULL);

    /* cleanup && destroy all open windows */
    for (i=0; i < IGL_MAXWINDOWS; i++)
    {
        igl_windowT *wptr = &igl->openWindows[i];


        if (wptr->wnd != NULL)
        {
            /* deallocate display lists (allocated winopen()) */
            if (wptr->fontBase != 0)
            {
                glDeleteLists (wptr->fontBase, 96);
            }

            for (j=0; j < IGL_WLAYER_MARKER; j++)
            {
                if (wptr->hrcs[j] != NULL)
                {
                    wglDeleteContext (wptr->hrcs[j]);
                }
            }

            if (wptr->hdc != NULL)
            {
                ReleaseDC (wptr->wnd, wptr->hdc);
            }
            DestroyWindow (wptr->wnd);
        }
    }

    /* cleanup texdef's images */
    for (i=0; i < IGL_MAXTEXDEFS; i++)
    {
        if (igl->texDefs[i].image != NULL)
        {
            free (igl->texDefs[i].image);
        }
    }

    /* delete globals */
    free (igl);

    /* shutdown the threads */
    ExitProcess (ret);

    return (ret);
}
#else       /* PLATFORM_WIN32 */
#if 0
____________________________ X11 common stuph ____________________________
() {}
#endif
int
igl_X11main (int argc, char **argv)
{
    int i, j, ret = 0;
    int tmp[2];
    int aidx, attribs[64];
    XVisualInfo *vi;


    /***************************************
        init (TBD: move to greset())!!!
    ****************************************/
    igl = (igl_globalsT *)malloc (sizeof (igl_globalsT));
    FCN_EXIT (igl == NULL, -1,
        {
            printf ("malloc() failed!\n");
        });

    /* app-related */
    memset (igl, 0, sizeof (igl_globalsT));
    igl->appInstance = XOpenDisplay (NULL);
    FCN_EXIT (igl->appInstance == NULL, -1,
        {
            printf ("XOpenDisplay() failed!\n");
        });
#ifdef _DEBUG
    XSynchronize (igl->appInstance, 1);
#endif


    /* setup GL visuals */
    FCN_EXIT (!glXQueryExtension (igl->appInstance, &tmp[0], &tmp[1]), -1,
        {
            printf ("glXQueryExtension() failed!\n");
        });

    aidx = 0;
    attribs[aidx++] = GLX_RGBA;
    attribs[aidx++] = GLX_DOUBLEBUFFER;
    attribs[aidx++] = GLX_DEPTH_SIZE;
    attribs[aidx++] = 16;
#if 0
    attribs[aidx++] = GLX_RED_SIZE;
    attribs[aidx++] = 4;
    attribs[aidx++] = GLX_GREEN_SIZE;
    attribs[aidx++] = 4;
    attribs[aidx++] = GLX_BLUE_SIZE;
    attribs[aidx++] = 4;
    attribs[aidx++] = GLX_ALPHA_SIZE;
    attribs[aidx++] = 4;
    attribs[aidx++] = GLX_STENCIL_SIZE;
    attribs[aidx++] = 1;
    attribs[aidx++] = GLX_ACCUM_RED_SIZE;
    attribs[aidx++] = 16;
    attribs[aidx++] = GLX_ACCUM_BLUE_SIZE;
    attribs[aidx++] = 16;
    attribs[aidx++] = GLX_ACCUM_GREEN_SIZE;
    attribs[aidx++] = 16;
    attribs[aidx++] = GLX_ACCUM_ALPHA_SIZE;
    attribs[aidx++] = 16;
    if (wptr->flags & IGL_WFLAGS_STEREOBUFFER)
    {
        attribs[aidx++] = GLX_STEREO;
    }
#endif
    attribs[aidx++] = None;
    vi = glXChooseVisual (igl->appInstance, DefaultScreen (igl->appInstance), attribs);
    FCN_EXIT (vi == NULL, -1,
        {
            printf ("glXChooseVisual () failed!");
        });
    memcpy (&igl->visualInfo, vi, sizeof (XVisualInfo));
    XFree (vi);
    vi = NULL;


    /* window-related */
    igl->currentWindow = -1;
    igl->winWidth = IGL_WINDOWWIDTH;
    igl->winHeight = IGL_WINDOWHEIGHT;
    /* color-related */
    igl->colorPalette[BLACK] = RGB (0, 0, 0);
    igl->colorPalette[RED] = RGB (255, 0, 0);
    igl->colorPalette[GREEN] = RGB (0, 255, 0);
    igl->colorPalette[YELLOW] = RGB (255, 255, 0);
    igl->colorPalette[BLUE] = RGB (0, 0, 255);
    igl->colorPalette[MAGENTA] = RGB (255, 0, 255);
    igl->colorPalette[CYAN] = RGB (0, 255, 255);
    igl->colorPalette[WHITE] = RGB (255, 255, 255);
    /* vertex-related */
    igl->curveSegments = 30;
    /* matrix-related */
    igl->matrixMode = MSINGLE;
    /* light-related */
    {
        igl_lmMaterialDefT *matPtr = &igl->materialDefs[0];
        igl_lmLightDefT *lightPtr = &igl->lightDefs[0];
        igl_lmLmodelDefT *lmPtr = &igl->lmodelDefs[0];


        matPtr->ambient[0] = matPtr->ambient[1] = matPtr->ambient[2] = 0.2f;
        matPtr->ambient[3] = 1.0f;
        matPtr->diffuse[0] = matPtr->diffuse[1] = matPtr->diffuse[2] = 0.8f;
        matPtr->diffuse[3] = 1.0f;
        matPtr->specular[3] = 1.0f;
        matPtr->emission[3] = 1.0f;

        lightPtr->ambient[3] = 1.0f;
        lightPtr->position[2] = 1.0f;
        lightPtr->spotDirection[2] = -1.0f;
        lightPtr->spotLight[1] = 180.0f;

        lmPtr->ambient[0] = lmPtr->ambient[1] = lmPtr->ambient[2] = 0.2f;
        lmPtr->ambient[3] = 1.0f;
        lmPtr->attenuation[0] = 1.0f;
    }
    /* texture-related */
    igl->tevDefs[0].tvMode = GL_MODULATE;

    /* run the real main() */
    ret = main (argc, argv);


exit:
    if (igl != NULL)
    {
        /*
            TBD:
            1. close fullscreen mode
            2. destroy all menus
            #3. release glx
            4. destroy all windows
                a. delete GL lists
                b. delete glx contexts
                c. release GC
                d. close window
            5. free texdef's images
            #6. close X display
        */
        if (igl->appInstance != NULL)
        {
            glXMakeCurrent (igl->appInstance, None, NULL);

            /* cleanup && destroy all open windows */
            for (i=0; i < IGL_MAXWINDOWS; i++)
            {
                igl_windowT *wptr = &igl->openWindows[i];


                if (wptr->wnd != IGL_NULLWND)
                {
                    /* deallocate display lists (allocated winopen()) */
                    if (wptr->fontBase != 0)
                    {
                        glDeleteLists (wptr->fontBase, 96);
                    }

                    for (j=0; j < IGL_WLAYER_MARKER; j++)
                    {
                        if (wptr->hrcs[j] != NULL)
                        {
                            glXDestroyContext (igl->appInstance, wptr->hrcs[j]);
                        }
                    }

                    if (wptr->hdc != NULL)
                    {
                        XFreeGC (igl->appInstance, wptr->hdc);
                    }
                    XDestroyWindow (igl->appInstance, wptr->wnd);
                }
            }

            XCloseDisplay (igl->appInstance);
        }

        free (igl);
        igl = NULL;
    }

#if 0
    return (ret);   /* TBD: upon return(), we dump core. on exit() we don't */
#else
    exit (ret);
#endif
}
#endif      /* PLATFORM_WIN32 */




#if 0
____________________________ misc IrisGL stuph ____________________________
() {}
#endif
/* DESC: pushattributes - pushes down the attribute stack */
void
pushattributes ()
{
    IGL_CHECKINITV ();
    glPushAttrib (GL_ALL_ATTRIB_BITS);
}


/* DESC: popattributes - pops the attribute stack */
void
popattributes ()
{
    IGL_CHECKINITV ();
    glPopAttrib ();
}


/* DESC: ? */
void
sginap (long nap)
{
    sleep (nap);
}


/* memset the (old) UNIX way */
#if PLATFORM_WIN32
void
bzero (void *ptr, int len)
{
    memset (ptr, 0, len);
}
#endif


/* DESC: defpattern - defines patterns */
void
defpattern (short n, short size, unsigned short mask[])
{
}


/* DESC: setpattern - selects a pattern for filling polygons and rectangles */
void
setpattern (short index)
{
}


/* DESC: glcompat - controls compatibility modes */
void
glcompat (long mode, long value)
{
}


/* DESC: getgdesc - gets graphics system description */
long
getgdesc (long inquiry)
{
    igl_windowT *wptr;
    IGL_CHECKINIT (-1);


    wptr = IGL_CTX ();

        
    if (inquiry == GD_XMMAX || inquiry == GD_YMMAX || inquiry == GD_XPMAX || inquiry == GD_YPMAX)
    {
#if PLATFORM_WIN32
        DEVMODE devMode;


        if (EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &devMode))
        {
            /* we assume 72dpi = 72pixels/25.4mm */
            devMode.dmPelsWidth = (inquiry == GD_XMMAX) ?
                (long)(devMode.dmPelsWidth*25.4f/72.0f) : devMode.dmPelsWidth;
            devMode.dmPelsHeight = (inquiry == GD_YMMAX) ?
                (long)(devMode.dmPelsHeight*25.4f/72.0f) : devMode.dmPelsHeight;

            return ((inquiry == GD_XMMAX || inquiry == GD_XPMAX) ?
                devMode.dmPelsWidth : devMode.dmPelsHeight);
        }
        else
        {
            return (-1);
        }
#else
        if (inquiry == GD_XMMAX)
        {
            return (DisplayWidthMM (igl->appInstance, DefaultScreen (igl->appInstance)));
        }
        else if (inquiry == GD_XPMAX)
        {
            return (DisplayWidth (igl->appInstance, DefaultScreen (igl->appInstance)));
        }
        else if (inquiry == GD_YMMAX)
        {
            return (DisplayHeightMM (igl->appInstance, DefaultScreen (igl->appInstance)));
        }
        else /* GD_YPMAX */
        {
            return (DisplayHeight (igl->appInstance, DefaultScreen (igl->appInstance)));
        }
#endif
    }

    if (inquiry == GD_ZMIN || inquiry == GD_ZMAX)
    {
        return ((inquiry == GD_ZMIN) ? 0 : 32);
    }


    if (inquiry == GD_BITS_ACBUF_HW)
    {
        /* for now it's ok */
        return (0);
    }

#if 0
    if (inquiry == GD_BITS_ACBUF || inquiry == GD_BITS_CURSOR)
    {
        int format;
        PIXELFORMATDESCRIPTOR pfd;


        format = GetPixelFormat (wptr->hdc);
        if (format <= 0)
        {
            return (-1);
        }

        memset (&pfd, 0, sizeof(PIXELFORMATDESCRIPTOR));
        pfd.nSize = sizeof (PIXELFORMATDESCRIPTOR);
        DescribePixelFormat (wptr->hdc, format, sizeof(PIXELFORMATDESCRIPTOR), &pfd);


    }
#endif


    return (-1);
}


