#include "igl.h"
#include "iglcmn.h"




#if 0
____________________________ obj functions ____________________________
() {}
#endif
/* DESC: genobj - returns a unique integer for use as an object identifier */
Object
genobj ()
{
    IGL_CHECKINIT (0);

    return (glGenLists(1));
}


/* DESC: makeobj - creates an object */
void
makeobj (Object obj)
{
    IGL_CHECKINITV ();

    if (!glIsList(obj))
    {
        return;
    }

    glNewList (obj, GL_COMPILE);
}


/* DESC: closeobj - closes an object definition */
void
closeobj ()
{
    IGL_CHECKINITV ();
    glEndList ();
}


/* DESC: callobj - draws an instance of an object */
void
callobj (Object obj)
{
    IGL_CHECKINITV ();

    if (glIsList(obj))
    {
        glCallList (obj);
    }
}


/* DESC: delobj - deletes an object */
void
delobj (Object obj)
{
    IGL_CHECKINITV ();

    if (glIsList(obj))
    {
        glDeleteLists (obj, 1);
    }
}


/* DESC: isobj - returns whether an object exists */
Boolean
isobj (Object obj)
{
    IGL_CHECKINIT (FALSE);

    return (glIsList(obj));
}


/* DESC: editobj - opens an object definition for editing */
void
editobj (Object obj)
{
    IGL_CHECKINITV ();
    if (glIsList(obj))
    {
        glDeleteLists (obj, 1);
        glNewList (obj, GL_COMPILE);
    }
}


/* DESC: objreplace - overwrites existing display list routines with new ones */
void
objreplace (Tag t)
{
    IGL_CHECKINITV ();
    /* TBD: implement Tags as display lists, e.g. list in a list! */
}


/* DESC: objdelete - deletes routines from an object */
void
objdelete (Tag tag1, Tag tag2)
{
    /* TBD: implement Tags as display lists, e.g. list in a list! */
}


/* DESC: objdelete - deletes routines from an object */
void
objinsert (Tag t)
{
    /* TBD: implement Tags as display lists, e.g. list in a list! */
}


#if 0
____________________________ tag functions ____________________________
() {}
#endif
/* DESC: gentag - returns a unique integer for use as a tag */
Tag
gentag ()
{
    /* no support for tags in OpenGL... */
    return (0);
}


/* DESC: maketag - numbers a routine in the display list */
void
maketag (Tag tag)
{
    /* no support for tags in OpenGL... */
}


/* DESC: deltag - deletes a tag from the current open object */
void
deltag (Tag tag)
{
    /* no support for tags in OpenGL... */
}


/* DESC: istag - returns whether a tag exists in the current open object */
Boolean
istag (Tag tag)
{
    /* no support for tags in OpenGL... */
    return (FALSE);
}


#if 0
____________________________ misc functions ____________________________
() {}
#endif
/* DESC: chunksize - specifies minimum object size in memory */
void
chunksize (long chunk)
{
    /* not needed in OpenGL */
}


/* DESC: compactify - compacts the memory storage of an object */
void
compactify (Object obj)
{
    /* not needed in OpenGL */
}



