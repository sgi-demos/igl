#include "igl.h"
#include "iglcmn.h"
#include <stdarg.h>




#if PLATFORM_X11
#if 0
____________________________ X11 helpers ____________________________
() {}
#endif
static HMENU
_igl_X11createPopup (igl_windowT *wptr)
{
    int wflags;
    XSetWindowAttributes swAttribs;


    wflags = CWBackPixel | CWBorderPixel | CWEventMask;

    memset (&swAttribs, 0, sizeof (XSetWindowAttributes));
    swAttribs.event_mask = KeyPressMask | ButtonPressMask;
    return (XCreateWindow (igl->appInstance, wptr->wnd, 0, 0, 100, 50, 0,
        igl->visualInfo.depth, InputOutput, igl->visualInfo.visual, wflags, &swAttribs));
}
#endif


#if 0
____________________________ IGL helpers ____________________________
() {}
#endif
static int
_igl_findMenuPlaceholder ()
{
    int i;


    for (i=0; i < IGL_MAXMENUS; i++)
    {
        if (igl->menus[i].hmenu == IGL_NULLMENU)
        {
            return (i);
        }
    }

    return (-1);
}


static void
_igl_parseMenuItem (char *startPtr, char *endPtr, va_list mlist, igl_menuT *menu, igl_menuItemT *item)
{
    int i;
    char *s;


    /* item 'title' needs special handling as it's not marked with %t as menu title is */
    if (item != NULL)
    {
        strncpy (item->title, startPtr, 255);
        s = strchr (item->title, '%');
        if (s != NULL)
        {
            *s = '\0';
            if (s-1 > item->title && *(s-1) == ' ')
            {
                *(s-1) = '\0';
            }
        }
    }

    i = 0;
    s = startPtr;
    while (s != NULL && (s+1 <= endPtr))
    {
        if (*s != '%')
        {
            if (s+1 > endPtr)
            {
                /* end-of-string */
                break;
            }

            s ++;
            continue;
        }

        if (s+1 > endPtr)
        {
            /* end-of-string */
            break;
        }
        s ++;


        switch (*s)
        {
            case 't':
#if 1
                strcpy (menu->title, "<- ");
                strncat (menu->title, startPtr, s-startPtr-2);
                strcat (menu->title, " ->");
#else
                strncpy (menu->title, startPtr, s-startPtr-2);
#endif
                break;

            case 'F':
                menu->routine = (int(*)(int, ...))va_arg (mlist, void *);
                break;

            case 'f':
                if (item != NULL)
                {
                    item->routine = (int(*)(int, ...))va_arg (mlist, void *);
                }
                break;

            case 'l':
                if (item != NULL)
                {
                    item->delimiter = 1;
                }
                break;

            case 'm':
                if (item != NULL)
                {
                    item->submenu = (long)va_arg (mlist, long);
                }
                break;

            case 'n':
                if (item != NULL)
                {
                    item->dontExecuteRoutine = 1;
                }
                break;

            case 'x':
                if (item != NULL && isdigit(*(s+1)))
                {
                    item->id = atoi (s+1);
                }
                break;
        }

        s ++;
    }
}


static int
_igl_parseMenu (int pup, String str, va_list args)
{
    int i, j, id;
    char *startPtr, *endPtr, tmpStr[256];
    igl_menuT *menu;
    igl_menuItemT *item;


    /* if pup is specified, we're called from addtopup(), else from defpup() */
    if (pup >= 0 && pup < IGL_MAXMENUS)
    {
        id = pup;
    }
    else
    {
        id = _igl_findMenuPlaceholder ();
        if (id == -1)
        {
            return (-1);
        }
        menu = &igl->menus[id];
    }


    strncpy (tmpStr, str, 255);

    /* chop menu defines into pieces */
    startPtr = strtok (tmpStr, "|");
    endPtr = startPtr+strlen(startPtr)-1;

    /* parse menu and items */
    i = -1;
    item = NULL;
    while (startPtr != NULL)
    {
        _igl_parseMenuItem (startPtr, endPtr, args, menu, item);

        startPtr = strtok (NULL, "|");
        if (startPtr == NULL)
        {
            break;
        }
        endPtr = startPtr+strlen(startPtr)-1;

        if (i+1 >= IGL_MAXMENUITEMS)
        {
            break;
        }
        i ++;
        item = &menu->items[i];
    }


#if PLATFORM_WIN32      // TBD
    if (id != pup) /* if (id == pup) we were called from addtopup() */
    {
        /* create the menu w/items if any */
        menu->hmenu = CreatePopupMenu ();
    }

#   if 1
    if (menu->title[0] != '\0')
    {
        AppendMenu (menu->hmenu, MF_STRING | MF_GRAYED, 0, menu->title);
        AppendMenu (menu->hmenu, MF_SEPARATOR | MF_GRAYED, 0, menu->title);
    }
#   endif

    for (j=0; j < IGL_MAXMENUITEMS; j++)
    {
        if (menu->items[j].title[0] != '\0')
        {
            AppendMenu (menu->hmenu, MF_STRING, j, menu->items[j].title);
        }
        else if (menu->items[j].delimiter)
        {
            AppendMenu (menu->hmenu, MF_SEPARATOR, j, NULL);
        }
    }
#else
    if (id != pup) /* if (id == pup) we were called from addtopup() */
    {
        /* create the menu w/items if any */
        menu->hmenu = _igl_X11createPopup (IGL_CTX ());
    }
#endif

    return (id);
}


#if 0
____________________________ menu functions ____________________________
() {}
#endif
/* DESC: defpup - defines a menu */
long
defpup (String str, ...)
{
    int id;
    va_list mlist;


    IGL_CHECKINIT (-1);

    va_start (mlist, str);
    id = _igl_parseMenu (-1, str, mlist);
    va_end (mlist);

    return (id);
}


/* DESC: newpup - allocates and initializes a structure for a new menu */
long
newpup ()
{
    long id;


    IGL_CHECKINIT (-1);

    id = _igl_findMenuPlaceholder ();
    if (id != -1)
    {
#if PLATFORM_WIN32  // TBD
        igl->menus[id].hmenu = CreatePopupMenu ();
#else
#endif
    }

    return (id);
}


/* DESC: addtopup - adds items to an existing pop-up menu */
void
addtopup (long pup, String str, ...)
{
    va_list mlist;


    IGL_CHECKINITV ();
    if (pup < 0 || pup >= IGL_MAXMENUS || igl->menus[pup].hmenu == IGL_NULLMENU)
    {
        return;
    }

    /* TBD: check if the menu was created with defpup() or newpup() */
    va_start (mlist, str);
    _igl_parseMenu (pup, str, mlist);
    va_end (mlist);
}


/* DESC: dopup - displays the specified pop-up menu */
long
dopup (long pup)
{
    long ret = -1, id;
    igl_menuT *menu;
    igl_menuItemT *item;
#if PLATFORM_WIN32
    POINT p;
    MSG msg;
#endif

    IGL_CHECKINIT (-1);
    if (pup < 0 || pup >= IGL_MAXMENUS || igl->menus[pup].hmenu == IGL_NULLMENU)
    {
        return (-1);
    }


#if PLATFORM_WIN32  // TBD
    menu = &igl->menus[pup];
    GetCursorPos (&p);
    TrackPopupMenu (menu->hmenu, TPM_CENTERALIGN | TPM_VCENTERALIGN,
        p.x, p.y, 0, IGL_CTX()->wnd, NULL);

    /*
       we process the WM_COMMAND sent by TrackPopupMenu() right away, as there is
       no chance of WndProc() catching it before dopup() returns
    */
    if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE) && msg.message == WM_COMMAND)
    {
        if (HIWORD(msg.wParam) == 0) // && igl->menus[pup].hmenu == (HMENU)msg.lParam)
        {
            id = (long)LOWORD (msg.wParam);
        }
    }
#else
    return (-1);
#endif

    if (id < 0 || id > IGL_MAXMENUITEMS)
    {
        return (-1);
    }


    item = &menu->items[id];

    /* 1. menu item has a routine() defined -> call it */
    if (item->routine != NULL)
    {
        ret = (*item->routine)(id);
    }
    else
    {
        if (item->id != 0)
        {
            ret = item->id;
        }
        else
        {
            ret = id;
        }
    }

    /* 2. menu item has a routine() defined -> call it, unless the item should not execute it */
    /* NOTE: if 1. is true, return value is passed as an argument to this routine */
    if (menu->routine != NULL && !item->dontExecuteRoutine)
    {
        ret = (*menu->routine)(ret);
    }
    else
    {
        if (item->id != 0)
        {
            ret = item->id;
        }
        else
        {
            ret = id;
        }
    }

    return (ret);
}


/* DESC: freepup - deallocates a menu */
void
freepup (long pup)
{
    IGL_CHECKINITV ();
    if (pup < 0 || pup >= IGL_MAXMENUS || igl->menus[pup].hmenu == IGL_NULLMENU)
    {
        return;
    }

#if PLATFORM_WIN32  // TBD
    DestroyMenu (igl->menus[pup].hmenu);
#else
#endif
    memset (&igl->menus[pup], 0, sizeof(igl_menuT));
}


/* DESC: pupmode, endpupmode - obsolete routines */
void
pupmode ()
{
}


/* DESC: pupmode, endpupmode - obsolete routines */
void
endpupmode ()
{
}


/* DESC: ??? */
void
pupcolor (long clr)
{
}



