- IGL is an Open Source port of IrisGL library to (Win32) OpenGL
- current version is 0.1.6 alpha
- it is released under GNU GPL (www.gnu.org), see gpl.txt
- for more info, check my homepage at http://users.volja.net/wesley/igl.html
- a better readme and installation/compilation notes may be available when
  the X-window version is finished (may take a while)

email: matevzb@email.si
Matevz Bradac
