#include "igl.h"
#include "iglcmn.h"




#if 0
____________________________ IGL helpers ____________________________
() {}
#endif
static void
_igl_parseLmMaterial (short index, short np, float *lmdefs)
{
    int i;
    igl_lmMaterialDefT *lmptr;
    GLboolean endParse = FALSE;


    lmptr = &igl->materialDefs[index];
    memset (lmptr, 0, sizeof(igl_lmMaterialDefT));

    /* IrisGL supplies 3 values, OpenGL needs 4 */
    lmptr->ambient[3] = lmptr->colorIndexes[3] = lmptr->emission[3] = lmptr->specular[3] = 1.0f;

    for (i=0; !endParse; i++)
    {
        switch ((int)lmdefs[i])
        {
            case ALPHA: /* = 4th parameter to diffuse */
                lmptr->flags |= IGL_LMMATERIALFLAGS_DIFFUSE;
                lmptr->diffuse[3] = lmdefs[i+1];
                i ++;
                break;

            case AMBIENT:
                lmptr->flags |= IGL_LMMATERIALFLAGS_AMBIENT;
                memcpy (&lmptr->ambient[0], &lmdefs[i+1], 3*sizeof(float));
                i += 3;
                break;

            case COLORINDEXES:
                lmptr->flags |= IGL_LMMATERIALFLAGS_COLORINDEXES;
                /* ignored when in RGBA mode! */
                memcpy (&lmptr->colorIndexes[0], &lmdefs[i+1], 3*sizeof(float));
                i += 3;
                break;

            case DIFFUSE:
                lmptr->flags |= IGL_LMMATERIALFLAGS_DIFFUSE;
                memcpy (&lmptr->diffuse[0], &lmdefs[i+1], 3*sizeof(float));
                i += 3;
                break;

            case EMISSION:
                lmptr->flags |= IGL_LMMATERIALFLAGS_EMISSION;
                memcpy (&lmptr->emission[0], &lmdefs[i+1], 3*sizeof(float));
                i += 3;
                break;

            case SHININESS:
                lmptr->flags |= IGL_LMMATERIALFLAGS_SHININESS;
                lmptr->shininess = lmdefs[i+1];
                i ++;
                break;

            case SPECULAR:
                lmptr->flags |= IGL_LMMATERIALFLAGS_SPECULAR;
                memcpy (&lmptr->specular[0], &lmdefs[i+1], 3*sizeof(float));
                i += 3;
                break;
        }

        endParse = ((np > 0 && i == np) || lmdefs[i] == LMNULL);
    }
}


void
_igl_setLmMaterial (short target, short index)
{
    int ogltype = (target == MATERIAL) ? GL_FRONT : GL_BACK;
    igl_lmMaterialDefT *lmptr = &igl->materialDefs[index];


    if (lmptr->flags & IGL_LMMATERIALFLAGS_AMBIENT)
    {
        glMaterialfv (ogltype, GL_AMBIENT, lmptr->ambient);
    }
    if (lmptr->flags & IGL_LMMATERIALFLAGS_COLORINDEXES)
    {
        glMaterialfv (ogltype, GL_COLOR_INDEXES, lmptr->colorIndexes);
    }
    if (lmptr->flags & IGL_LMMATERIALFLAGS_DIFFUSE)
    {
        glMaterialfv (ogltype, GL_DIFFUSE, lmptr->diffuse);
    }
    if (lmptr->flags & IGL_LMMATERIALFLAGS_EMISSION)
    {
        glMaterialfv (ogltype, GL_EMISSION, lmptr->emission);
    }
    if (lmptr->flags & IGL_LMMATERIALFLAGS_SHININESS)
    {
        glMaterialf (ogltype, GL_SHININESS, lmptr->shininess);
    }
    if (lmptr->flags & IGL_LMMATERIALFLAGS_SPECULAR)
    {
        glMaterialfv (ogltype, GL_SPECULAR, lmptr->specular);
    }
}


static void
_igl_parseLmLight (short index, short np, float *lmdefs)
{
    int i;
    igl_lmLightDefT *lmptr;
    GLboolean endParse = FALSE;


    lmptr = &igl->lightDefs[index];
    memset (lmptr, 0, sizeof(igl_lmLightDefT));
    /* IrisGL supplies 3 values, OpenGL needs 4 */
    lmptr->ambient[3] = lmptr->lcolor[3] = lmptr->position[3] = lmptr->spotLight[3] = 1.0f;

    for (i=0; !endParse; i++)
    {
        switch ((int)lmdefs[i])
        {
            case AMBIENT:
                lmptr->flags |= IGL_LMLIGHTFLAGS_AMBIENT;
                memcpy (&lmptr->ambient[0], &lmdefs[i+1], 3*sizeof(float));
                i += 3;
                break;

            case LCOLOR:
                lmptr->flags |= IGL_LMLIGHTFLAGS_LCOLOR;
                memcpy (&lmptr->lcolor[0], &lmdefs[i+1], 3*sizeof(float));
                i += 3;
                break;

            case POSITION:
                lmptr->flags |= IGL_LMLIGHTFLAGS_POSITION;
                memcpy (&lmptr->position[0], &lmdefs[i+1], 4*sizeof(float));
                i += 4;
                break;

            case SPOTDIRECTION:
                lmptr->flags |= IGL_LMLIGHTFLAGS_SPOTDIRECTION;
                memcpy (&lmptr->spotDirection[0], &lmdefs[i+1], 3*sizeof(float));
                i += 3;
                break;

            case SPOTLIGHT:
                lmptr->flags |= IGL_LMLIGHTFLAGS_SPOTLIGHT;
                memcpy (&lmptr->spotLight[0], &lmdefs[i+1], 2*sizeof(float));
                i += 2;
                break;
        }

        endParse = ((np > 0 && i == np) || lmdefs[i] == LMNULL);
    }
}


void
_igl_setLmLight (short target, short index)
{
    igl_lmLightDefT *lmptr = &igl->lightDefs[index];


    if (lmptr->flags & IGL_LMLIGHTFLAGS_AMBIENT)
    {
        glLightfv (GL_LIGHT0+index, GL_AMBIENT, lmptr->ambient);
        /* TBD: */
//        glLightfv (GL_LIGHT0+index, GL_DIFFUSE, {1.0f, 1.0f, 1.0f, 1.0f});
//        glLightfv (GL_LIGHT0+index, GL_SPECULAR, {1.0f, 1.0f, 1.0f, 1.0f});
    }
    if (lmptr->flags & IGL_LMLIGHTFLAGS_LCOLOR)
    {
        /* TBD: no equivalent in OpenGL? */
        glLightfv (GL_LIGHT0+index, GL_DIFFUSE, lmptr->lcolor);
    }
    if (lmptr->flags & IGL_LMLIGHTFLAGS_POSITION)
    {
        glLightfv (GL_LIGHT0+index, GL_POSITION, lmptr->position);
    }
    if (lmptr->flags & IGL_LMLIGHTFLAGS_SPOTDIRECTION)
    {
        glLightfv (GL_LIGHT0+index, GL_SPOT_DIRECTION, lmptr->spotDirection);
    }
    if (lmptr->flags & IGL_LMLIGHTFLAGS_SPOTLIGHT)
    {
        glLightf (GL_LIGHT0+index, GL_SPOT_EXPONENT, lmptr->spotLight[0]);
        glLightf (GL_LIGHT0+index, GL_SPOT_CUTOFF, lmptr->spotLight[1]);
    }
    glEnable (GL_LIGHT0+index);
}


static void
_igl_parseLmLightModel (short index, short np, float *lmdefs)
{
    int i;
    igl_lmLmodelDefT *lmptr;
    GLboolean endParse = FALSE;


    lmptr = &igl->lmodelDefs[index];
    memset (lmptr, 0, sizeof(igl_lmLmodelDefT));
    /* IrisGL supplies 3 values, OpenGL needs 4 */
    lmptr->ambient[3] = 1.0f;

    for (i=0; !endParse; i++)
    {
        switch ((int)lmdefs[i])
        {
            case AMBIENT:
                lmptr->flags |= IGL_LMMODELFLAGS_AMBIENT;
                memcpy (&lmptr->ambient[0], &lmdefs[i+1], 3*sizeof(float));
                i += 3;
                break;

            case ATTENUATION:
                lmptr->flags |= IGL_LMMODELFLAGS_ATTENUATION;
                memcpy (&lmptr->attenuation[0], &lmdefs[i+1], 2*sizeof(float));
                i += 2;
                break;

            case ATTENUATION2:
                lmptr->flags |= IGL_LMMODELFLAGS_ATTENUATION2;
                lmptr->attenuation2 = lmdefs[i+1];
                i ++;
                break;

            case LOCALVIEWER:
                lmptr->flags |= IGL_LMMODELFLAGS_LOCALVIEWER;
                lmptr->localViewer = (lmdefs[i+1] == 1.0f) ? 1.0f : 0.0f;
                i ++;
                break;

            case TWOSIDE:
                lmptr->flags |= IGL_LMMODELFLAGS_TWOSIDE;
                lmptr->twoSide = (lmdefs[i+1] == 1.0f) ? 1.0f : 0.0f;
                i ++;
                break;
        }

        endParse = ((np > 0 && i == np) || lmdefs[i] == LMNULL);
    }
}


void
_igl_setLmLightModel (short target, short index)
{
    igl_lmLmodelDefT *lmptr = &igl->lmodelDefs[index];


    if (lmptr->flags & IGL_LMMODELFLAGS_AMBIENT)
    {
        glLightModelfv (GL_LIGHT_MODEL_AMBIENT, lmptr->ambient);
    }
    if (lmptr->flags & IGL_LMMODELFLAGS_ATTENUATION)
    {
        glLightf (GL_LIGHT0+index, GL_CONSTANT_ATTENUATION, lmptr->attenuation[0]);
        glLightf (GL_LIGHT0+index, GL_LINEAR_ATTENUATION, lmptr->attenuation[1]);
    }
    if (lmptr->flags & IGL_LMMODELFLAGS_ATTENUATION2)
    {
        glLightf (GL_LIGHT0+index, GL_QUADRATIC_ATTENUATION, lmptr->attenuation2);
    }
    if (lmptr->flags & IGL_LMMODELFLAGS_LOCALVIEWER)
    {
        glLightModelf (GL_LIGHT_MODEL_LOCAL_VIEWER, lmptr->localViewer);
    }
    if (lmptr->flags & IGL_LMMODELFLAGS_TWOSIDE)
    {
        glLightModelf (GL_LIGHT_MODEL_TWO_SIDE, lmptr->twoSide);
    }
}


#if 0
____________________________ light functions ____________________________
() {}
#endif
/* DESC: lmdef - defines or modifies a material, light source, or lighting model */
void
lmdef (short deftype, short index, short np, float *props)
{
    IGL_CHECKINITV ();


    switch (deftype)
    {
        case DEFMATERIAL:
            if (index > 0 && index < IGL_MAXLMDEFS)
            {
                _igl_parseLmMaterial (index, np, props);
            }
            break;

        case DEFLIGHT:
            if (index > 0 && index < IGL_MAXLMDEFS)
            {
               _igl_parseLmLight (index, np, props);
            }
            break;

        case DEFLMODEL:
            if (index > 0 && index < IGL_MAXLMDEFS)
            {
                _igl_parseLmLightModel (index, np, props);
            }
            break;
    }
}


/* DESC: lmbind - selects a new material, light source, or lighting model */
void
lmbind (short target, short index)
{
    IGL_CHECKINITV ();

    if (index < 0 || index > IGL_MAXLMDEFS)
    {
        return;
    }
    /* index=0 disables lighting when target is MATERIAL or LMODEL! */
    if (index == 0 && (target == MATERIAL || target == LMODEL))
    {
        glDisable (GL_LIGHTING);
        return;
    }
    glEnable (GL_LIGHTING);


    switch (target)
    {
        case MATERIAL:
        case BACKMATERIAL:
            _igl_setLmMaterial (target, index);
            break;

        case LIGHT0:
        case LIGHT1:
        case LIGHT2:
        case LIGHT3:
        case LIGHT4:
        case LIGHT5:
        case LIGHT6:
        case LIGHT7:
            _igl_setLmLight (target, index);
            break;

        case LMODEL:
            _igl_setLmLightModel (target, index);
            break;
    }
}


/* DESC: lmcolor - change the effect of color commands while lighting is active */
void
lmcolor (long mode)
{
    IGL_CHECKINITV ();

    if (mode == LMC_NULL)
    {
        glDisable (GL_COLOR_MATERIAL);
        return;
    }

    /* TBD: what to do with GL_FRONT/GL_BACK/GL_FRONT_AND_BACK? */
    switch (mode)
    {
        case LMC_COLOR: /* nothing to do for color? */
            break;

        case LMC_EMISSION:
            glColorMaterial (GL_FRONT_AND_BACK, GL_EMISSION);
            break;

        case LMC_AMBIENT:
            glColorMaterial (GL_FRONT_AND_BACK, GL_AMBIENT);
            break;

        case LMC_DIFFUSE:
            glColorMaterial (GL_FRONT_AND_BACK, GL_DIFFUSE);
            break;

        case LMC_SPECULAR:
            glColorMaterial (GL_FRONT_AND_BACK, GL_SPECULAR);
            break;

        case LMC_AD:
            glColorMaterial (GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
            break;
    }    

    glEnable (GL_COLOR_MATERIAL);
}


