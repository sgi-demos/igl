#include "igl.h"
#include "iglcmn.h"




/* DESC: mmode - sets the current matrix mode */
void
mmode (short mode)
{
    IGL_CHECKINITV ();
    if (mode != MSINGLE && mode != MVIEWING && mode != MPROJECTION && mode != MTEXTURE)
    {
        return;
    }

    igl->matrixMode = mode;
    switch (mode)
    {
        case MSINGLE:
            /* set to GL_MODELVIEW and this is the only one used */
            glMatrixMode (GL_MODELVIEW);
            break;

        case MVIEWING:
            glMatrixMode (GL_MODELVIEW);
            break;

        case MPROJECTION:
            glMatrixMode (GL_PROJECTION);
            break;

        case MTEXTURE:
            glMatrixMode (GL_TEXTURE);
            break;
    }
}


/* DESC: getmmode - returns the current matrix mode */
long
getmmode ()
{
    IGL_CHECKINIT (MSINGLE);
    return (igl->matrixMode);
}


/* DESC: loadmatrix - loads a transformation matrix */
void
loadmatrix (Matrix m)
{
    GLfloat mat[16];


    IGL_CHECKINITV ();
    
    memcpy (&mat[0], &m[0][0], 4*sizeof(float));
    memcpy (&mat[4], &m[1][0], 4*sizeof(float));
    memcpy (&mat[8], &m[2][0], 4*sizeof(float));
    memcpy (&mat[12], &m[3][0], 4*sizeof(float));
    glLoadMatrixf (mat);
}


/* DESC: getmatrix - returns a copy of a transformation matrix */
void
getmatrix (Matrix m)
{
    GLfloat mat[16];


    IGL_CHECKINITV ();

    switch (igl->matrixMode)
    {
        case MSINGLE:
        case MVIEWING:
            glGetFloatv (GL_MODELVIEW_MATRIX, mat);
            break;

        case MPROJECTION:
            glGetFloatv (GL_PROJECTION_MATRIX, mat);
            break;

        case MTEXTURE:
            glGetFloatv (GL_TEXTURE_MATRIX, mat);
            break;
    }

    memcpy (&m[0][0], &mat[0], 4*sizeof(float));
    memcpy (&m[1][0], &mat[4], 4*sizeof(float));
    memcpy (&m[2][0], &mat[8], 4*sizeof(float));
    memcpy (&m[3][0], &mat[12], 4*sizeof(float));
}


/* DESC: multmatrix - premultiplies the current transformation matrix */
void
multmatrix (Matrix m)
{
    GLfloat mat[16];


    IGL_CHECKINITV ();

    /* convert 2D 4x4 array to 1D 16x1 array */
    memcpy (&mat[0], &m[0][0], 4*sizeof(float));
    memcpy (&mat[4], &m[1][0], 4*sizeof(float));
    memcpy (&mat[8], &m[2][0], 4*sizeof(float));
    memcpy (&mat[12], &m[3][0], 4*sizeof(float));

    glMultMatrixf (mat);
}


/* DESC: pushmatrix - pushes down the transformation matrix stack */
void
pushmatrix ()
{
    IGL_CHECKINITV ();
    /* TBD: man page says: "should not be called when mmode is MPROJECTION or MTEXTURE" */
    glPushMatrix ();
}


/* DESC: pushmatrix - pops the transformation matrix stack */
void
popmatrix ()
{
    IGL_CHECKINITV ();
    /* TBD: man page says: "should not be called when mmode is MPROJECTION or MTEXTURE" */
    glPopMatrix ();
}


/* DESC: rotate, rot - rotates the current matrix */
void
rot (float amount, char angle)
{
    IGL_CHECKINITV ();

    if (angle == 'x')
    {
        glRotatef (amount, 1, 0, 0);
    }
    else if (angle == 'y')
    {
        glRotatef (amount, 0, 1, 0);
    }
    else
    {
        glRotatef (amount, 0, 0, 1);
    }
}


/* DESC: rotate, rot - rotates the current matrix */
void
rotate (Angle amount, char angle)
{
    IGL_CHECKINITV ();

    /* NOTE: amount is an integer in specified in tenths of degrees */
    if (angle == 'x')
    {
        glRotatef (amount*0.1f, 1, 0, 0);
    }
    else if (angle == 'y')
    {
        glRotatef (amount*0.1f, 0, 1, 0);
    }
    else
    {
        glRotatef (amount*0.1f, 0, 0, 1);
    }
}


/* DESC: translate - translates the current matrix */
void
translate (Coord x, Coord y, Coord z)
{
    IGL_CHECKINITV ();
    glTranslatef (x, y, z);
}


/* DESC: scale - scales and mirrors the current matrix */
void
scale (float x, float y, float z)
{
    IGL_CHECKINITV ();
    glScalef (x, y, z);
}


/* DESC: polarview - defines the viewer's position in polar coordinates */
void
polarview (Coord dist, Angle azim, Angle inc, Angle twist)
{
    IGL_CHECKINITV ();

    glTranslatef (0, 0, -dist);
    glRotatef (-twist*0.1f, 0, 0, 1);
    glRotatef (-inc*0.1f, 1, 0, 0);
    glRotatef (-azim*0.1f, 0, 0, 1);
}


/* DESC: clipplane - specify a plane against which all geometry is clipped */
void
clipplane (long index, long mode, float *params)
{
    IGL_CHECKINITV ();

    /* TBD: OpenGL supports 0..GL_MAX_CLIP_PLANES, IrisGL 0..5 - so what do we do? */
    if (index < 0 || index > 5 || (mode == CP_DEFINE && params == NULL))
    {
        return;
    }

    if (mode == CP_OFF)
    {
        glDisable (GL_CLIP_PLANE0+index);
    }
    else if (mode == CP_ON)
    {
        glEnable (GL_CLIP_PLANE0+index);
    }
    else if (mode == CP_DEFINE)
    {
        glClipPlane (GL_CLIP_PLANE0+index, (GLdouble *)params);
    }
}


#if 0
____________________________ projection/viewport functions ____________________________
() {}
#endif
/* DESC: ortho, ortho2 - define an orthographic projection transformation */
void
ortho (Coord left, Coord right, Coord bottom, Coord top, Coord near_, Coord far_)
{
    int cm;


    IGL_CHECKINITV ();

    /*
        in MSINGLE, ortho() loads the matrix onto the matrix stack, otherwise
        it changes the projection matrix
    */
    if (igl->matrixMode != MSINGLE && igl->matrixMode != MPROJECTION)
    {
        glGetIntegerv (GL_MATRIX_MODE, &cm);
        glMatrixMode (GL_PROJECTION);
    }

    glLoadIdentity ();
    glOrtho ((GLdouble)left, (GLdouble)right, (GLdouble)bottom, (GLdouble)top,
        (GLdouble)near_, (GLdouble)far_);

    if (igl->matrixMode != MSINGLE && igl->matrixMode != MPROJECTION)
    {
        glMatrixMode (cm);
    }
}


/* DESC: ortho, ortho2 - define an orthographic projection transformation */
void
ortho2 (Coord left, Coord right, Coord bottom, Coord top)
{
    int cm;


    IGL_CHECKINITV ();

    /*
        in MSINGLE, ortho2() loads the matrix onto the matrix stack, otherwise
        it changes the projection matrix
    */
    if (igl->matrixMode != MSINGLE && igl->matrixMode != MPROJECTION)
    {
        glGetIntegerv (GL_MATRIX_MODE, &cm);
        glMatrixMode (GL_PROJECTION);
    }

    glLoadIdentity ();
    gluOrtho2D ((GLdouble)left, (GLdouble)right, (GLdouble)bottom, (GLdouble)top);

    if (igl->matrixMode != MSINGLE && igl->matrixMode != MPROJECTION)
    {
        glMatrixMode (cm);
    }
}


/* DESC: window - defines a perspective projection transformation */
void
window (Coord left, Coord right, Coord bottom, Coord top, Coord near_, Coord far_)
{
    int cm;


    IGL_CHECKINITV ();

    /* window() doesn't touch MVIEWING or MTEXTURE */
    if (igl->matrixMode != MSINGLE && igl->matrixMode != MPROJECTION)
    {
        glGetIntegerv (GL_MATRIX_MODE, &cm);
        glMatrixMode (GL_PROJECTION);
    }

    glLoadIdentity ();
    glFrustum ((GLdouble)left, (GLdouble)right, (GLdouble)bottom, (GLdouble)top,
        (GLdouble)near_, (GLdouble)far_);

    if (igl->matrixMode != MSINGLE && igl->matrixMode != MPROJECTION)
    {
        glMatrixMode (cm);
    }
}


/* DESC: perspective - defines a perspective projection transformation */
void
perspective (Angle fovy, float aspect, Coord near_, Coord far_)
{
    int cm;


    IGL_CHECKINITV ();

    /* perspective() doesn't touch MVIEWING or MTEXTURE */
    if (igl->matrixMode != MSINGLE && igl->matrixMode != MPROJECTION)
    {
        glGetIntegerv (GL_MATRIX_MODE, &cm);
        glMatrixMode (GL_PROJECTION);
    }

    glLoadIdentity ();
    gluPerspective ((GLdouble)fovy, (GLdouble)aspect, (GLdouble)near_, (GLdouble)far_);

    if (igl->matrixMode != MSINGLE && igl->matrixMode != MPROJECTION)
    {
        glMatrixMode (cm);
    }
}


/* DESC: viewport - allocates a rectangular area of the window for an image */
void
viewport (Screencoord left, Screencoord right, Screencoord bottom, Screencoord top)
{
    long width, height;


    IGL_CHECKINITV ();

    width = right-left;
    height = top-bottom;
    if (width <= 0 || height <= 0)
    {
        return;
    }

    glViewport (left, bottom, width, height);
}


/* DESC: getviewport - gets a copy of the dimensions of the current viewport */
void
getviewport (Screencoord *left, Screencoord *right, Screencoord *bottom, Screencoord *top)
{
    int viewport[4];


    IGL_CHECKINITV ();

    glGetIntegerv (GL_VIEWPORT, viewport);
    if (left != NULL)
    {
        *left = viewport[0];
    }
    if (right != NULL)
    {
        *right = viewport[0] + viewport[2];
    }
    if (bottom != NULL)
    {
        *bottom = viewport[1];
    }
    if (top != NULL)
    {
        *top = viewport[1] + viewport[3];
    }
}


/* DESC: reshapeviewport - sets the viewport to the dimensions of the current graphics window */
void
reshapeviewport ()
{
    IGL_CHECKINITV ();
    glViewport (0, 0, IGL_CTX()->width, IGL_CTX()->height);
}


/* DESC: pushviewport - pushes down the viewport stack */
void
pushviewport ()
{
    IGL_CHECKINITV ();
    glPushAttrib (GL_VIEWPORT_BIT);
}


/* DESC: popviewport - pops the viewport stack */
void
popviewport ()
{
    IGL_CHECKINITV ();
    glPopAttrib ();
}


/* DESC: lookat - defines a viewing transformation */
void
lookat (Coord vx, Coord vy, Coord vz, Coord px, Coord py, Coord pz, Angle twist)
{
    IGL_CHECKINITV ();

    /* TBD: we're missing IrisGL->OpenGL conversion here methinks */
    glRotatef ((float)-twist*0.1f, 0, 0, 1);
    gluLookAt (vx, vy, vz, px, py, pz, 0, 1, 0);
}


/* DESC: gl_invertmat - invert a matrix??? */
/* NOTE: ripped from Mesa */
void
gl_invertmat (Matrix m, Matrix out)
{
    GLdouble *_tmp;
    GLdouble wtmp[4][8];
    GLdouble m0, m1, m2, m3, s;
    GLdouble *r0, *r1, *r2, *r3;
#define SWAP_ROWS(a, b) { _tmp = a; (a)=(b); (b)=_tmp; }
#define MAT(m, r, c) (m)[(c)][(r)]


    IGL_CHECKINITV ();

    r0 = wtmp[0], r1 = wtmp[1], r2 = wtmp[2], r3 = wtmp[3];

    r0[0] = MAT(m, 0, 0), r0[1] = MAT(m, 0, 1),
        r0[2] = MAT(m, 0, 2), r0[3] = MAT(m, 0, 3),
        r0[4] = 1.0, r0[5] = r0[6] = r0[7] = 0.0,
        r1[0] = MAT(m, 1, 0), r1[1] = MAT(m, 1, 1),
        r1[2] = MAT(m, 1, 2), r1[3] = MAT(m, 1, 3),
        r1[5] = 1.0, r1[4] = r1[6] = r1[7] = 0.0,
        r2[0] = MAT(m, 2, 0), r2[1] = MAT(m, 2, 1),
        r2[2] = MAT(m, 2, 2), r2[3] = MAT(m, 2, 3),
        r2[6] = 1.0, r2[4] = r2[5] = r2[7] = 0.0,
        r3[0] = MAT(m, 3, 0), r3[1] = MAT(m, 3, 1),
        r3[2] = MAT(m, 3, 2), r3[3] = MAT(m, 3, 3),
        r3[7] = 1.0, r3[4] = r3[5] = r3[6] = 0.0;

    /* choose pivot - or die */
    if (fabs(r3[0]) > fabs(r2[0]))
    {
        SWAP_ROWS (r3, r2);
    }
    if (fabs(r2[0]) > fabs(r1[0]))
    {
        SWAP_ROWS (r2, r1);
    }
    if (fabs(r1[0]) > fabs(r0[0]))
    {
        SWAP_ROWS (r1, r0);
    }
    if (r0[0] == 0)
    {
        return;
    }

    /* eliminate first variable     */
    m1 = r1[0] / r0[0];
    m2 = r2[0] / r0[0];
    m3 = r3[0] / r0[0];
    s = r0[1];
    r1[1] -= m1 * s;
    r2[1] -= m2 * s;
    r3[1] -= m3 * s;
    s = r0[2];
    r1[2] -= m1 * s;
    r2[2] -= m2 * s;
    r3[2] -= m3 * s;
    s = r0[3];
    r1[3] -= m1 * s;
    r2[3] -= m2 * s;
    r3[3] -= m3 * s;
    s = r0[4];
    if (s != 0.0)
    {
        r1[4] -= m1 * s;
        r2[4] -= m2 * s;
        r3[4] -= m3 * s;
    }
    s = r0[5];
    if (s != 0.0)
    {
        r1[5] -= m1 * s;
        r2[5] -= m2 * s;
        r3[5] -= m3 * s;
    }
    s = r0[6];
    if (s != 0.0)
    {
        r1[6] -= m1 * s;
        r2[6] -= m2 * s;
        r3[6] -= m3 * s;
    }
    s = r0[7];
    if (s != 0.0)
    {
        r1[7] -= m1 * s;
        r2[7] -= m2 * s;
        r3[7] -= m3 * s;
    }

    /* choose pivot - or die */
    if (fabs(r3[1]) > fabs(r2[1]))
    {
        SWAP_ROWS (r3, r2);
    }
    if (fabs(r2[1]) > fabs(r1[1]))
    {
        SWAP_ROWS (r2, r1);
    }
    if (r1[1] == 0)
    {
        return;
    }

    /* eliminate second variable */
    m2 = r2[1] / r1[1];
    m3 = r3[1] / r1[1];
    r2[2] -= m2 * r1[2];
    r3[2] -= m3 * r1[2];
    r2[3] -= m2 * r1[3];
    r3[3] -= m3 * r1[3];
    s = r1[4];
    if (0.0 != s)
    {
        r2[4] -= m2 * s;
        r3[4] -= m3 * s;
    }
    s = r1[5];
    if (0.0 != s)
    {
        r2[5] -= m2 * s;
        r3[5] -= m3 * s;
    }
    s = r1[6];
    if (0.0 != s)
    {
        r2[6] -= m2 * s;
        r3[6] -= m3 * s;
    }
    s = r1[7];
    if (0.0 != s)
    {
        r2[7] -= m2 * s;
        r3[7] -= m3 * s;
    }

    /* choose pivot - or die */
    if (fabs(r3[2]) > fabs(r2[2]))
    {
        SWAP_ROWS (r3, r2);
    }
    if (r2[2] == 0)
    {
        return;
    }

    /* eliminate third variable */
    m3 = r3[2] / r2[2];
    r3[3] -= m3 * r2[3], r3[4] -= m3 * r2[4],
        r3[5] -= m3 * r2[5], r3[6] -= m3 * r2[6], r3[7] -= m3 * r2[7];

    /* last check */
    if (r3[3] == 0)
    {
        return;
    }

    s = 1.0 / r3[3];        /* now back substitute row 3 */
    r3[4] *= s;
    r3[5] *= s;
    r3[6] *= s;
    r3[7] *= s;

    m2 = r2[3];            /* now back substitute row 2 */
    s = 1.0 / r2[2];
    r2[4] = s * (r2[4] - r3[4] * m2), r2[5] = s * (r2[5] - r3[5] * m2),
        r2[6] = s * (r2[6] - r3[6] * m2), r2[7] = s * (r2[7] - r3[7] * m2);
    m1 = r1[3];
    r1[4] -= r3[4] * m1, r1[5] -= r3[5] * m1,
        r1[6] -= r3[6] * m1, r1[7] -= r3[7] * m1;
    m0 = r0[3];
    r0[4] -= r3[4] * m0, r0[5] -= r3[5] * m0,
        r0[6] -= r3[6] * m0, r0[7] -= r3[7] * m0;

    m1 = r1[2];            /* now back substitute row 1 */
    s = 1.0 / r1[1];
    r1[4] = s * (r1[4] - r2[4] * m1), r1[5] = s * (r1[5] - r2[5] * m1),
        r1[6] = s * (r1[6] - r2[6] * m1), r1[7] = s * (r1[7] - r2[7] * m1);
    m0 = r0[2];
    r0[4] -= r2[4] * m0, r0[5] -= r2[5] * m0,
        r0[6] -= r2[6] * m0, r0[7] -= r2[7] * m0;

    m0 = r0[1];            /* now back substitute row 0 */
    s = 1.0 / r0[0];
    r0[4] = s * (r0[4] - r1[4] * m0), r0[5] = s * (r0[5] - r1[5] * m0),
        r0[6] = s * (r0[6] - r1[6] * m0), r0[7] = s * (r0[7] - r1[7] * m0);

    MAT(out, 0, 0) = (float)r0[4];
    MAT(out, 0, 1) = (float)r0[5], MAT(out, 0, 2) = (float)r0[6];
    MAT(out, 0, 3) = (float)r0[7], MAT(out, 1, 0) = (float)r1[4];
    MAT(out, 1, 1) = (float)r1[5], MAT(out, 1, 2) = (float)r1[6];
    MAT(out, 1, 3) = (float)r1[7], MAT(out, 2, 0) = (float)r2[4];
    MAT(out, 2, 1) = (float)r2[5], MAT(out, 2, 2) = (float)r2[6];
    MAT(out, 2, 3) = (float)r2[7], MAT(out, 3, 0) = (float)r3[4];
    MAT(out, 3, 1) = (float)r3[5], MAT(out, 3, 2) = (float)r3[6];
    MAT(out, 3, 3) = (float)r3[7];

#undef MAT
#undef SWAP_ROWS
}


/* DESC: gl_invertmat - invert a matrix??? */
void
gl_invert4d (Matrix m, Matrix out)
{
    gl_invertmat (m, out);
}


/* DESC: mapw - maps a point on the screen into a line in 3-D world coordinates */
void
mapw (Object obj, Screencoord x, Screencoord y, Coord *wx1, Coord *wy1, Coord *wz1, 
      Coord *wx2, Coord *wy2, Coord *wz2)
{
    GLdouble modelMatrix[16], projMatrix[16], tx, ty, tz;
    GLint viewport[4];


    IGL_CHECKINITV ();
    if (wx1 == NULL || wy1 == NULL || wz1 == NULL || wx2 == NULL || wy2 == NULL || wz2 == NULL)
    {
        return;
    }

    glPushMatrix ();
    glPushAttrib (GL_VIEWPORT_BIT);

    callobj (obj);
    glGetDoublev (GL_MODELVIEW_MATRIX, modelMatrix);
    glGetDoublev (GL_PROJECTION_MATRIX, projMatrix);
    glGetIntegerv (GL_VIEWPORT, viewport);

    glPopAttrib ();
    glPopMatrix ();

    gluUnProject (x, viewport[3]-y-1, 0, modelMatrix, projMatrix, viewport, &tx, &ty, &tz);
    *wx1 = *wx2 = (GLfloat)tx;
    *wy1 = *wy2 = (GLfloat)ty;
    *wz1 = *wz2 = (GLfloat)tz;
}


/* DESC: mapw2 - maps a point on the screen into 2-D world coordinates */
void
mapw2 (Object obj, Screencoord x, Screencoord y, Coord *wx, Coord *wy)
{
    GLdouble modelMatrix[16], projMatrix[16], tx, ty, tz;
    GLint viewport[4];


    IGL_CHECKINITV ();
    if (wx == NULL || wy == NULL)
    {
        return;
    }

    glPushMatrix ();
    glPushAttrib (GL_VIEWPORT_BIT);

    callobj (obj);
    glGetDoublev (GL_MODELVIEW_MATRIX, modelMatrix);
    glGetDoublev (GL_PROJECTION_MATRIX, projMatrix);
    glGetIntegerv (GL_VIEWPORT, viewport);

    glPopAttrib ();
    glPopMatrix ();

    gluUnProject (x, viewport[3]-y-1, 0, modelMatrix, projMatrix, viewport, &tx, &ty, &tz);
    *wx = (GLfloat)tx;
    *wy = (GLfloat)ty;
}


/* DESC: screenspace - map world space to absolute screen coordinates */
void
screenspace ()
{
    long xmin, ymin, xmax, ymax;


    IGL_CHECKINITV ();

    getorigin (&xmin, &ymin);
    xmax = getgdesc (GD_XPMAX);
    ymax = getgdesc (GD_YPMAX);

    viewport ((short)-xmin, (short)(xmax-xmin), (short)-ymin, (short)(ymax-ymin));
    ortho2 (-0.5f, xmax+0.5f, -0.5f, ymax+0.5f);
}

