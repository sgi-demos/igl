#include "igl.h"
#include "iglcmn.h"




#if 0
____________________________ polf functions ____________________________
() {}
#endif
/* DESC: polf, polfi, polfs, polf2, polf2i, polf2s - draws a filled polygon */
void
polf (long n, const Coord parray[][3])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_POLYGON);
        for (i=0; i < n; i ++)
        {
            glVertex3fv (&parray[i][0]);
        }
    glEnd ();
}


void
polfi (long n, const Icoord parray[][3])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_POLYGON);
        for (i=0; i < n; i ++)
        {
            glVertex3iv (&parray[i][0]);
        }
    glEnd ();
}


void
polfs (long n, const Scoord parray[][3])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_POLYGON);
        for (i=0; i < n; i ++)
        {
            glVertex3sv (&parray[i][0]);
        }
    glEnd ();
}


void
polf2 (long n, const Coord parray[][2])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_POLYGON);
        for (i=0; i < n; i ++)
        {
            glVertex2fv (&parray[i][0]);
        }
    glEnd ();
}


void
polf2i (long n, const Icoord parray[][2])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_POLYGON);
        for (i=0; i < n; i ++)
        {
            glVertex2iv (&parray[i][0]);
        }
    glEnd ();
}


void
polf2s (long n, const Scoord parray[][2])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_POLYGON);
        for (i=0; i < n; i ++)
        {
            glVertex2sv (&parray[i][0]);
        }
    glEnd ();
}


#if 0
____________________________ poly functions ____________________________
() {}
#endif
/* DESC: poly, polyi, polys, poly2, poly2i, poly2s - outlines a polygon */
void
poly (long n, const Coord parray[][3])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_LINE_LOOP);
        for (i=0; i < n; i ++)
        {
            glVertex3fv (&parray[i][0]);
        }
    glEnd ();
}


void
polyi (long n, const Icoord parray[][3])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_LINE_LOOP);
        for (i=0; i < n; i ++)
        {
            glVertex3iv (&parray[i][0]);
        }
    glEnd ();
}


void
polys (long n, const Scoord parray[][3])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_LINE_LOOP);
        for (i=0; i < n; i ++)
        {
            glVertex3sv (&parray[i][0]);
        }
    glEnd ();
}


void
poly2 (long n, const Coord parray[][2])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_LINE_LOOP);
        for (i=0; i < n; i ++)
        {
            glVertex2fv (&parray[i][0]);
        }
    glEnd ();
}


void
poly2i (long n, const Icoord parray[][2])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_LINE_LOOP);
        for (i=0; i < n; i ++)
        {
            glVertex2iv (&parray[i][0]);
        }
    glEnd ();
}


void
poly2s (long n, const Scoord parray[][2])
{
    int i;


    IGL_CHECKINITV ();
    if (n < 2 || n > IGL_MAXPOLYVERTICES)
    {
        return;
    }

    glBegin (GL_LINE_LOOP);
        for (i=0; i < n; i ++)
        {
            glVertex2sv (&parray[i][0]);
        }
    glEnd ();
}


/* DESC: polymode - control the rendering of polygons */
void
polymode (long mode)
{
    IGL_CHECKINITV ();

    if (mode == PYM_FILL)
    {
        glPolygonMode (GL_FRONT_AND_BACK, GL_FILL);
    }
    else if (mode == PYM_POINT)
    {
        glPolygonMode (GL_FRONT_AND_BACK, GL_POINT);
    }
    /* PYM_HOLLOW not supported by OpenGL */
    else if (mode == PYM_LINE || mode == PYM_HOLLOW)
    {
        glPolygonMode (GL_FRONT_AND_BACK, GL_LINE);
    }
}


/* DESC: polysmooth - specify antialiasing of polygons */
void
polysmooth (long mode)
{
    IGL_CHECKINITV ();

    if (mode == PYSM_OFF)
    {
        glDisable (GL_POLYGON_SMOOTH);
    }
    /* PYSM_SHRINK not supported in OpenGL */
    else if (mode == PYSM_ON || mode == PYSM_SHRINK)
    {
        glEnable (GL_POLYGON_SMOOTH);
    }
}


#if 0
____________________________ pmv functions ____________________________
() {}
#endif
/* DESC: pmv, pmvi, pmvs, pmv2, pmv2i, pmv2s - specifies the first point of a polygon */
void
pmv (Coord x, Coord y, Coord z)
{
    IGL_CHECKINITV ();
    glBegin (GL_POLYGON);
        glVertex3f (x, y, z);
}


/* DESC: pmv, pmvi, pmvs, pmv2, pmv2i, pmv2s - specifies the first point of a polygon */
void
pmvi (Icoord x, Icoord y, Icoord z)
{
    pmv ((Coord)x, (Coord)y, (Coord)z);
}


/* DESC: pmv, pmvi, pmvs, pmv2, pmv2i, pmv2s - specifies the first point of a polygon */
void
pmvs (Scoord x, Scoord y, Scoord z)
{
    pmv ((Coord)x, (Coord)y, (Coord)z);
}


/* DESC: pmv, pmvi, pmvs, pmv2, pmv2i, pmv2s - specifies the first point of a polygon */
void
pmv2 (Coord x, Coord y)
{
    IGL_CHECKINITV ();
    glBegin (GL_POLYGON);
        glVertex2f (x, y);
}


/* DESC: pmv, pmvi, pmvs, pmv2, pmv2i, pmv2s - specifies the first point of a polygon */
void
pmv2i (Icoord x, Icoord y)
{
    pmv2 ((Coord)x, (Coord)y);
}


/* DESC: pmv, pmvi, pmvs, pmv2, pmv2i, pmv2s - specifies the first point of a polygon */
void
pmv2s (Scoord x, Scoord y)
{
    pmv2 ((Coord)x, (Coord)y);
}


#if 0
____________________________ pdr functions ____________________________
() {}
#endif
/* DESC: pdr, pdri, pdrs, pdr2, pdr2i, pdr2s - specifies the next point of a polygon */
void
pdr (Coord x, Coord y, Coord z)
{
    IGL_CHECKINITV ();
    glVertex3f (x, y, z);
}


/* DESC: pdr, pdri, pdrs, pdr2, pdr2i, pdr2s - specifies the next point of a polygon */
void
pdri (Icoord x, Icoord y, Icoord z)
{
    pdr ((float)x, (float)y, (float)z);
}


/* DESC: pdr, pdri, pdrs, pdr2, pdr2i, pdr2s - specifies the next point of a polygon */
void
pdrs (Scoord x, Scoord y, Scoord z)
{
    pdr ((float)x, (float)y, (float)z);
}


/* DESC: pdr, pdri, pdrs, pdr2, pdr2i, pdr2s - specifies the next point of a polygon */
void
pdr2 (Coord x, Coord y)
{
    IGL_CHECKINITV ();
    glVertex2f (x, y);
}


/* DESC: pdr, pdri, pdrs, pdr2, pdr2i, pdr2s - specifies the next point of a polygon */
void
pdr2i (Coord x, Coord y)
{
    pdr2 ((float)x, (float)y);
}


/* DESC: pdr, pdri, pdrs, pdr2, pdr2i, pdr2s - specifies the next point of a polygon */
void
pdr2s (Coord x, Coord y)
{
    pdr2 ((float)x, (float)y);
}


/* DESC: pclos - closes a filled polygon */
void
pclos ()
{
    IGL_CHECKINITV ();
    glEnd ();
}


/* DESC: spclos - obsolete routine */
void
spclos ()
{
    IGL_CHECKINITV ();
    glEnd ();
}


#if 0
____________________________ pnt functions ____________________________
() {}
#endif
/* DESC: pnt, pnti, pnts, pnt2, pnt2i, pnt2s - draws a point */
void
pnt (Coord x, Coord y, Coord z)
{
    IGL_CHECKINITV ();
    glBegin (GL_POINTS);
        glVertex3f (x, y, z);
    glEnd ();
}


/* DESC: pnt, pnti, pnts, pnt2, pnt2i, pnt2s - draws a point */
void
pnti (Icoord x, Icoord y, Icoord z)
{
    pnt ((float)x, (float)y, (float)z);
}


/* DESC: pnt, pnti, pnts, pnt2, pnt2i, pnt2s - draws a point */
void
pnts (Scoord x, Scoord y, Scoord z)
{
    pnt ((float)x, (float)y, (float)z);
}


/* DESC: pnt, pnti, pnts, pnt2, pnt2i, pnt2s - draws a point */
void
pnt2 (Coord x, Coord y)
{
    IGL_CHECKINITV ();
    glBegin (GL_POINTS);
        glVertex2f (x, y);
    glEnd ();
}


/* DESC: pnt, pnti, pnts, pnt2, pnt2i, pnt2s - draws a point */
void
pnt2i (Icoord x, Icoord y)
{
    pnt2 ((float)x, (float)y);
}


/* DESC: pnt, pnti, pnts, pnt2, pnt2i, pnt2s - draws a point */
void
pnt2s (Scoord x, Scoord y)
{
    pnt2 ((float)x, (float)y);
}


/* DESC: pntsize, pntsizef - specifies size of points */
void
pntsizef (float n)
{
    IGL_CHECKINITV ();
    glPointSize (n);
}


/* DESC: pntsize, pntsizef - specifies size of points */
void
pntsize (short n)
{
    IGL_CHECKINITV ();
    glPointSize ((float)n);
}


/* DESC: pntsmooth - specify antialiasing of points */
void
pntsmooth (unsigned long mode)
{
    IGL_CHECKINITV ();

    if (mode == SMP_OFF)
    {
        glDisable (GL_POINT_SMOOTH);
    }
    else if (mode & SMP_ON)
    {
        glEnable (GL_POINT_SMOOTH);

        if (mode & SMP_SMOOTHER)
        {
            glHint (GL_POINT_SMOOTH_HINT, GL_NICEST);
        }
        else
        {
            glHint (GL_POINT_SMOOTH_HINT, GL_FASTEST);
        }
    }
}


#if 0
____________________________ rect functions ____________________________
() {}
#endif
/* DESC: rect, recti, rects - outlines a rectangular region */
void
rect (Coord a, Coord b, Coord c, Coord d)
{
    IGL_CHECKINITV ();
    glBegin (GL_LINE_LOOP);
        glVertex2f (a, b);
        glVertex2f (c, b);
        glVertex2f (c, d);
        glVertex2f (a, d);
    glEnd ();
}


void
recti (Icoord a, Icoord b, Icoord c, Icoord d)
{
    IGL_CHECKINITV ();
    glBegin (GL_LINE_LOOP);
        glVertex2i (a, b);
        glVertex2i (c, b);
        glVertex2i (c, d);
        glVertex2i (a, d);
    glEnd ();
}


void
rects (Scoord a, Scoord b, Scoord c, Scoord d)
{
    IGL_CHECKINITV ();
    glBegin (GL_LINE_LOOP);
        glVertex2s (a, b);
        glVertex2s (c, b);
        glVertex2s (c, d);
        glVertex2s (a, d);
    glEnd ();
}


/* DESC: rectf, rectfi, rectfs - fills a rectangular area */
void
rectf (Coord a, Coord b, Coord c, Coord d)
{
    IGL_CHECKINITV ();
    glRectf (a, b, c, d);
}


void
rectfi (Icoord a, Icoord b, Icoord c, Icoord d)
{
    IGL_CHECKINITV ();
    glRecti (a, b, c, d);
}


void
rectfs (Scoord a, Scoord b, Scoord c, Scoord d)
{
    IGL_CHECKINITV ();
    glRects (a, b, c, d);
}


#if 0
____________________________ v functions ____________________________
() {}
#endif
/* DESC: v2d, v2f, v2i, v2s, v3d, v3f, v3i, v3s, v4d, v4f, v4i, v4s -
         transfers a 2-D, 3-D, or 4-D vertex to the graphics pipe */
void
v2f (float vector[2])
{
    IGL_CHECKINITV ();
    glVertex2fv (vector);
}


void
v2d (double vector[2])
{
    IGL_CHECKINITV ();
    glVertex2dv (vector);
}


void
v2i (int vector[2])
{
    IGL_CHECKINITV ();
    glVertex2iv (vector);
}


void
v2s (short vector[2])
{
    IGL_CHECKINITV ();
    glVertex2sv (vector);
}


void
v3f (float vector[3])
{
    IGL_CHECKINITV ();
    glVertex3fv (vector);
}


void
v3d (double vector[3])
{
    IGL_CHECKINITV ();
    glVertex3dv (vector);
}


void
v3i (int vector[3])
{
    IGL_CHECKINITV ();
    glVertex3iv (vector);
}


void
v3s (short vector[3])
{
    IGL_CHECKINITV ();
    glVertex3sv (vector);
}


void
v4f (float vector[4])
{
    IGL_CHECKINITV ();
    glVertex4fv (vector);
}


void
v4d (double vector[4])
{
    IGL_CHECKINITV ();
    glVertex4dv (vector);
}


void
v4i (int vector[4])
{
    IGL_CHECKINITV ();
    glVertex4iv (vector);
}


void
v4s (short vector[4])
{
    IGL_CHECKINITV ();
    glVertex4sv (vector);
}


#if 0
____________________________ arc functions ____________________________
() {}
#endif
/*
    NOTE on arc()'s in OpenGL:
    1. angles are in degrees (IrisGL - tenths of degrees)
    2. start angle is measured from positive y-axis (IrisGL - positive x-axis)
    3. arc is drawn clockwise (IrisGL - counterclockwise)
*/

/* DESC: arc, arci, arcs - draw a circular arc */
void
arc (Coord x, Coord y, Coord radius, Angle startAngle, Angle endAngle)
{
    GLUquadricObj *a;


    IGL_CHECKINITV ();
    if (radius == 0)
    {
        return;
    }

    a = gluNewQuadric ();
    if (a != NULL)
    {
        glPushMatrix ();
        glTranslatef (x, y, 0);
        gluPartialDisk (a, radius, radius, 1, 1,
            (double)startAngle/10.0 + 90.0, (double)endAngle/10.0 - 360.0);
        gluDeleteQuadric (a);
        glPopMatrix ();
    }
}


/* DESC: arc, arci, arcs - draw a circular arc */
void
arci (Icoord x, Icoord y, Icoord radius, Angle startAngle, Angle endAngle)
{
    arc ((Coord)x, (Coord)y, (Coord)radius, startAngle, endAngle);
}


/* DESC: arc, arci, arcs - draw a circular arc */
void
arcs (Scoord x, Scoord y, Scoord radius, Angle startAngle, Angle endAngle)
{
    arc ((Coord)x, (Coord)y, (Coord)radius, startAngle, endAngle);
}


/* DESC: arcf, arcfi, arcfs - draw a filled circular arc */
void
arcf (Coord x, Coord y, Coord radius, Angle startAngle, Angle endAngle)
{
    GLUquadricObj *a;


    IGL_CHECKINITV ();
    if (radius == 0)
    {
        return;
    }

    a = gluNewQuadric ();
    if (a != NULL)
    {
        glPushMatrix ();
        glTranslatef (x, y, 0);
        gluPartialDisk (a, 0, radius, 1, 1,
            (double)startAngle/10.0 + 90.0, (double)endAngle/10.0 - 360.0);
        gluDeleteQuadric (a);
        glPopMatrix ();
    }
}


/* DESC: arcf, arcfi, arcfs - draw a filled circular arc */
void
arcfi (Icoord x, Icoord y, Icoord radius, Angle startAngle, Angle endAngle)
{
    arcf ((Coord)x, (Coord)y, (Coord)radius, startAngle, endAngle);
}


/* DESC: arcf, arcfi, arcfs - draw a filled circular arc */
void
arcfs (Scoord x, Scoord y, Scoord radius, Angle startAngle, Angle endAngle)
{
    arcf ((Coord)x, (Coord)y, (Coord)radius, startAngle, endAngle);
}


#if 0
____________________________ circ functions ____________________________
() {}
#endif
/* DESC: circ, circi, circs - outlines a circle */
void
circ (Coord x, Coord y, Coord radius)
{
    GLUquadricObj *c;


    IGL_CHECKINITV ();
    if (radius <= 0)
    {
        return;
    }

    c = gluNewQuadric ();
    if (c != NULL)
    {
        glPushMatrix ();
        glTranslatef (x, y, 0);
        gluDisk (c, radius, radius, 1, 1);
        gluDeleteQuadric (c);
        glPopMatrix ();
    }
}


/* DESC: circ, circi, circs - outlines a circle */
void
circi (Icoord x, Icoord y, Icoord radius)
{
    circ ((float)x, (float)y, (float)radius);
}


/* DESC: circ, circi, circs - outlines a circle */
void
circs (Scoord x, Scoord y, Scoord radius)
{
    circ ((float)x, (float)y, (float)radius);
}


/* DESC: circf, circfi, circfs - draws a filled circle */
void
circf (Coord x, Coord y, Coord radius)
{
    GLUquadricObj *c;


    IGL_CHECKINITV ();
    if (radius <= 0)
    {
        return;
    }

    c = gluNewQuadric ();
    if (c != NULL)
    {
        glPushMatrix ();
        glTranslatef (x, y, 0);
        gluDisk (c, 0, radius, 1, 1);
        gluDeleteQuadric (c);
        glPopMatrix ();
    }
}


/* DESC: circf, circfi, circfs - draws a filled circle */
void
circif (Icoord x, Icoord y, Icoord radius)
{
    circf ((float)x, (float)y, (float)radius);
}


/* DESC: circf, circfi, circfs - draws a filled circle */
void
circsf (Scoord x, Scoord y, Scoord radius)
{
    circf ((float)x, (float)y, (float)radius);
}


#if 0
____________________________ mesh functions ____________________________
() {}
#endif
/* DESC: bgntmesh, endtmesh - delimit the vertices of a triangle mesh */
void
bgntmesh ()
{
    IGL_CHECKINITV ();
    glBegin (GL_TRIANGLE_STRIP);
}


/* DESC: bgntmesh, endtmesh - delimit the vertices of a triangle mesh */
void
endtmesh ()
{
    IGL_CHECKINITV ();
    glEnd ();
}


/* DESC: swaptmesh - toggles the triangle mesh register pointer */
void
swaptmesh ()
{
    /* TBD: can this be a NOP? */
}


/* DESC: bgnclosedline, endclosedline - delimit the vertices of a closed line */
void
bgnclosedline ()
{
    IGL_CHECKINITV ();
    glBegin (GL_LINE_LOOP);
}


/* DESC: bgnclosedline, endclosedline - delimit the vertices of a closed line */
void
endclosedline ()
{
    IGL_CHECKINITV ();
    glEnd ();
}


/* DESC: bgncurve, endcurve - delimit a NURBS curve definition */
void
bgncurve ()
{
    IGL_CHECKINITV ();

    igl->nurbsCurve = gluNewNurbsRenderer ();
    if (igl->nurbsCurve != NULL)
    {
        gluBeginCurve (igl->nurbsCurve);
    }
}


/* DESC: bgncurve, endcurve - delimit a NURBS curve definition */
void
endcurve ()
{
    IGL_CHECKINITV ();

    if (igl->nurbsCurve != NULL)
    {
        gluEndCurve (igl->nurbsCurve);
        gluDeleteNurbsRenderer (igl->nurbsCurve);
        igl->nurbsCurve = NULL;
    }
}


/* DESC: nurbscurve - controls the shape of a NURBS curve */
void 
nurbscurve (long knotCount, const double *knotList, long offset, const double *ctlArray,
            long order, long type)
{
    int otype;


    IGL_CHECKINITV ();

    if (igl->nurbsCurve != NULL)
    {
        if (type == N_V3D) otype = GL_MAP1_VERTEX_3;
        else if (type == N_V3DR) otype = GL_MAP1_VERTEX_4;
        else return;

#if 0        
        if (type == N_P2D) return;          /* TBD: not supported by OpenGL? */
        else if (type == N_P2DR) return;    /* TBD: not supported by OpenGL? */
#endif

        gluNurbsCurve (igl->nurbsCurve, knotCount, (float *)knotList, offset, (float *)ctlArray,
            order, otype);
    }
}


/* DESC: bgnsurface, endsurface - delimit a NURBS surface definition */
void
bgnsurface ()
{
    IGL_CHECKINITV ();

    igl->nurbsCurve = gluNewNurbsRenderer ();
    if (igl->nurbsCurve != NULL)
    {
        gluBeginSurface (igl->nurbsCurve);
    }
}


/* DESC: bgnsurface, endsurface - delimit a NURBS surface definition */
void
endsurface ()
{
    IGL_CHECKINITV ();

    if (igl->nurbsCurve != NULL)
    {
        gluEndSurface (igl->nurbsCurve);
        gluDeleteNurbsRenderer (igl->nurbsCurve);
        igl->nurbsCurve = NULL;
    }
}


/* nurbssurface - controls the shape of a NURBS surface */
void
nurbssurface (long scount, const double *sknot, long tcount, const double *tknot, long soffset,
              long toffset, const double *ctlArray, long sorder, long torder, long type)
{
    int otype;


    IGL_CHECKINITV ();

    if (igl->nurbsCurve != NULL)
    {
        if (type == N_V3D) otype = GL_MAP2_VERTEX_3;
        else if (type == N_V3DR) otype = GL_MAP2_VERTEX_4;
        else if (type == N_C4D) otype = GL_MAP2_COLOR_4;
        else if (type == N_T2D) otype = GL_MAP2_TEXTURE_COORD_2;
        else if (type == N_T2DR) otype = GL_MAP2_TEXTURE_COORD_3;
        else return;    /* others (e.g. N_C4DR) not supported */

        gluNurbsSurface (igl->nurbsCurve, scount, (float *)sknot, tcount, (float *)tknot,
            soffset, toffset, (float *)ctlArray, sorder, torder, otype);
    }
}


/* DESC: bgntrim, endtrim - delimit a NURBS surface trimming loop */
void
bgntrim ()
{
    IGL_CHECKINITV ();

    igl->nurbsCurve = gluNewNurbsRenderer ();
    if (igl->nurbsCurve != NULL)
    {
        gluBeginSurface (igl->nurbsCurve);
    }
}


/* DESC: bgntrim, endtrim - delimit a NURBS surface trimming loop */
void
endtrim ()
{
    IGL_CHECKINITV ();
    glEnd ();
}


/* DESC: pwlcurve - describes a piecewise linear trimming curve for NURBS surfaces */
void
pwlcurve (long n, double *dataArray, long byteSize, long type)
{
    IGL_CHECKINITV ();
    if (igl->nurbsCurve != NULL)
    {
        if (type != N_ST)   /* the only one supported by IrisGL */
        {
            return;
        }

        gluPwlCurve (igl->nurbsCurve, n, (float *)dataArray, byteSize, GLU_MAP1_TRIM_2);
    }
}


/* DESC: setnurbsproperty - sets a property for the display of trimmed NURBS surfaces */
void
setnurbsproperty (long property, float value)
{
    IGL_CHECKINITV ();

    if (igl->nurbsCurve != NULL)
    {
        if (property == N_ERRORCHECKING)
        {
            /* not supported in OpenGL? */
        }
        else if (property == N_PIXEL_TOLERANCE)
        {
            gluNurbsProperty (igl->nurbsCurve, GLU_SAMPLING_TOLERANCE, value);
        }
        else if (property == N_DISPLAY)
        {
            if (value == N_FILL)
            {
                gluNurbsProperty (igl->nurbsCurve, GLU_DISPLAY_MODE, GLU_FILL);
            }
            else if (value == N_OUTLINE_POLY)
            {
                gluNurbsProperty (igl->nurbsCurve, GLU_DISPLAY_MODE, GLU_OUTLINE_POLYGON);
            }
            else if (value == N_OUTLINE_PATCH)
            {
                gluNurbsProperty (igl->nurbsCurve, GLU_DISPLAY_MODE, GLU_OUTLINE_PATCH);
            }
        }
        else if (property == N_CULLING)
        {
            gluNurbsProperty (igl->nurbsCurve, GLU_CULLING, value);
        }
    }
}


/* DESC: bgnline, endline - delimit the vertices of a line */
void
bgnline ()
{
    IGL_CHECKINITV ();
    glBegin (GL_LINE_STRIP);
}


/* DESC: bgnline, endline - delimit the vertices of a line */
void
endline ()
{
    IGL_CHECKINITV ();
    glEnd ();
}


/* DESC: bgnpoint, endpoint - delimit the interpretation of vertex routines as points */
void
bgnpoint ()
{
    IGL_CHECKINITV ();
    glBegin (GL_POINTS);
}


/* DESC: bgnpoint, endpoint - delimit the interpretation of vertex routines as points */
void
endpoint ()
{
    IGL_CHECKINITV ();
    glEnd ();
}


/* DESC: bgnpolygon, endpolygon - delimit the vertices of a polygon */
void
bgnpolygon ()
{
    IGL_CHECKINITV ();
    glBegin (GL_POLYGON);
}


/* DESC: bgnpolygon, endpolygon - delimit the vertices of a polygon */
void
endpolygon ()
{
    IGL_CHECKINITV ();
    glEnd ();
}


/* DESC: bgnqstrip, endqstrip - delimit the vertices of a quadrilateral strip */
void
bgnqstrip ()
{
    IGL_CHECKINITV ();
    glBegin (GL_QUAD_STRIP);
}


/* DESC: bgnqstrip, endqstrip - delimit the vertices of a quadrilateral strip */
void
endqstrip ()
{
    IGL_CHECKINITV ();
    glEnd ();
}


/* DESC: crv - draws a curve */
void
crv (Coord points[4][3])
{
    crvn (4, points);
}


/* DESC: crvn - draws a series of curve segments */
void
crvn (long n, Coord points[][3])
{
    int i, j;


    /* TBD: only splines are supported for now!!!! */
    IGL_CHECKINITV ();
    if (n < 4)
    {
        return;
    }

    glEnable (GL_MAP1_VERTEX_3);
    for (j=0; j < n; j+=4)
    {
        glMap1f (GL_MAP1_VERTEX_3, 0, 1, 3, 4, points[j]);
        glBegin (GL_LINE_STRIP);
            for (i=0; i <= igl->curveSegments; i++)
            {
                glEvalCoord1f ((GLfloat)i/30.0f);
            }
        glEnd ();
    }
}


/* DESC: rcrv - draws a rational curve */
void
rcrv (Coord points[4][4])
{
    rcrvn (4, points);
}


/* DESC: rcrvn - draws a series of curve segments */
void
rcrvn (long n, Coord points[][4])
{
    int i, j;


    /* TBD: only splines are supported for now!!!! */
    IGL_CHECKINITV ();
    if (n < 4)
    {
        return;
    }

    glEnable (GL_MAP1_VERTEX_3);
    for (j=0; j < n; j+=4)
    {
        glMap1f (GL_MAP1_VERTEX_3, 0, 1, 4, 4, points[j]);
        glBegin (GL_LINE_STRIP);
            for (i=0; i <= igl->curveSegments; i++)
            {
                glEvalCoord1f ((GLfloat)i/30.0f);
            }
        glEnd ();
    }
}


/* DESC: curveprecision - sets number of line segments used to draw a curve segment */
void
curveprecision (short n)
{
    IGL_CHECKINITV ();
    if (n < 0 || n > IGL_MAXCURVESEGMENTS)
    {
        return;
    }
    igl->curveSegments = n;
}


#if 0
____________________________ misc functions ____________________________
() {}
#endif
/* DESC: nmode - specify renormalization of normals */
void
nmode (long mode)
{
    IGL_CHECKINITV ();

    /* TBD: check correctness of code with specification */
    if (mode == NAUTO)
    {
        glDisable (GL_NORMALIZE);
    }
    else if (mode == NNORMALIZE)
    {
        glEnable (GL_NORMALIZE);
    }
}


/* DESC: n3f - specifies a normal */
void
n3f (float *vector)
{
    IGL_CHECKINITV ();
    glNormal3fv (vector);
}


/* DESC: normal - obsolete routine */
void
normal (Coord *narray)
{
    IGL_CHECKINITV ();
    glNormal3fv (narray);
}


/* DESC: linesmooth - specify antialiasing of lines */
void
linesmooth (unsigned long mode)
{
    IGL_CHECKINITV ();

    if (mode == SML_OFF)
    {
        glDisable (GL_LINE_SMOOTH);
    }
    else if (mode & SML_ON)
    {
        glEnable (GL_LINE_SMOOTH);

        /* is this a good approximation? */
        if ((mode & SML_SMOOTHER) || (mode & SML_END_CORRECT))
        {
            glHint (GL_LINE_SMOOTH_HINT, GL_NICEST);
        }
        else
        {
            glHint (GL_LINE_SMOOTH_HINT, GL_FASTEST);
        }
    }
}


/* DESC: smoothline - obsolete routine */
void
smoothline (long mode)
{
    linesmooth (mode);
}


/* DESC: linewidth, linewidthf - specifies width of lines */
void
linewidth (short width)
{
    IGL_CHECKINITV ();
    glLineWidth ((float)width);
}


/* DESC: linewidth, linewidthf - specifies width of lines */
void
linewidthf (float width)
{
    IGL_CHECKINITV ();
    glLineWidth (width);
}


/* DESC: getlwidth - returns the current linewidth */
long
getlwidth ()
{
    int lw;


    IGL_CHECKINIT (1);

    glGetIntegerv (GL_LINE_WIDTH, &lw);
    return (lw);
}


/* DESC: deflinestyle - defines a linestyle */
void
deflinestyle (short n, Linestyle ls)
{
    IGL_CHECKINITV ();

    /* 0 cannot be changed! (solid line) */
    if (n <= 0 || n > IGL_MAXLINESTYLES)
    {
        return;
    }

    igl->lineStyles[n] = ls;
}


/* DESC: setlinestyle - selects a linestyle pattern */
void
setlinestyle (short n)
{
    IGL_CHECKINITV ();

    if (n < 0 || n > IGL_MAXLINESTYLES)
    {
        return;
    }

    if (n == 0)
    {
        /* solid line */
        glDisable (GL_LINE_STIPPLE);
    }
    else
    {
        glEnable (GL_LINE_STIPPLE);
        glLineStipple (1, (unsigned short)igl->lineStyles[n]);
    }
    igl->lineStyleIndex = n;
}


/* DESC: getlstyle - returns the current linestyle */
long
getlstyle ()
{
    IGL_CHECKINIT (0);
    return (igl->lineStyleIndex);
}


/* DESC: lsbackup - controls whether the ends of a line segment are colored */
void
lsbackup (Boolean b)
{
    /* not supported by OpenGL */
    IGL_CHECKINITV ();
}


/* DESC: getlsbackup - returns the state of linestyle backup mode */
Boolean
getlsbackup ()
{
    /* not supported by OpenGL */
    return (FALSE);
}


/* DESC: lsrepeat - sets a repeat factor for the current linestyle */
void
lsrepeat (long factor)
{
    IGL_CHECKINITV ();
    if (factor > 0 && factor < 256)
    {
        glLineStipple (factor, (unsigned short)igl->lineStyles[igl->lineStyleIndex]);
    }
}


/* DESC: getlsrepeat - returns the linestyle repeat count */
long
getlsrepeat ()
{
    int lsr;


    IGL_CHECKINIT (1);

    glGetIntegerv (GL_LINE_STIPPLE_REPEAT, &lsr);
    return (lsr);
}


/* DESC: concave - allows the system to draw concave polygons */
void
concave (Boolean enable)
{
    /* not supported in OpenGL - should be done with gluTess functions */
}


