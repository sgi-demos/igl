#include "igl.h"
#include "iglcmn.h"




LRESULT CALLBACK
WndProc (HWND wnd, UINT msg, WPARAM wParam, LPARAM lParam);

#if 0
____________________________ WIN32 stuph ____________________________
() {}
#endif
/* find a space for a new window in igl->openWindows. returns index (>= 0) if ok, -1 on error */
static int
_igl_findWindowPlaceholder ()
{
    int i;


    for (i=0; i < IGL_MAXWINDOWS; i++)
    {
        if (igl->openWindows[i].wnd == NULL)
        {
            return (i);
        }
    }

    return (-1);
}


/* initializes text/character properties of a window for use with lcharstr()/charstr() */
static void
_igl_textInit (igl_windowT *wptr)
{
    HFONT font, oldFont;


    wptr->fontBase = glGenLists (96);
//    font = CreateFont (0, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET,
    font = CreateFont (14, 8, 0, 0, FW_LIGHT, FALSE, FALSE, FALSE, ANSI_CHARSET,
        OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE | DEFAULT_PITCH,
        "Arial");
    oldFont = (HFONT)SelectObject (wptr->hdc, font);
    wglUseFontBitmaps (wptr->hdc, 32, 96, wptr->fontBase);
    SelectObject (wptr->hdc, oldFont);
    DeleteObject (font);
}


static long
_igl_createWindow (char *windowTitle, long parentId)
{
    int idx, format, wflags;
    WNDCLASS wc;
    PIXELFORMATDESCRIPTOR pfd;
    igl_windowT *wptr, *pptr;


    if (igl->appInstance == NULL)
    {
        return (-1);
    }

    idx = _igl_findWindowPlaceholder ();
    if (idx == -1)
    {
        return (-1);
    }
    igl->currentWindow = idx;
    wptr = &igl->openWindows[idx];

    pptr = (parentId != -1) ? &igl->openWindows[parentId] : NULL;


    /* init + set default window params */
    memset (wptr, 0, sizeof(igl_windowT));
    wptr->width = igl->winWidth;
    wptr->height = igl->winHeight;
    wptr->aspectX = wptr->aspectY = -1;
    wptr->acPlanes = 64;    /* Win32 default i guess */
    wptr->stenPlanes = 0;   /* IrisGL default */
    wptr->zbPlanes = 24;    /* IrisGL default */
    wptr->rgbPlanes = 32;

    if (pptr == NULL)
    {
        wptr->x = igl->winPosx;
        wptr->y = igl->winPosy;
        strncpy (wptr->title, windowTitle, 255);
    }
    else
    {
        /* TBD: position beside the parent window! */
        wptr->x = igl->winPosx;
        wptr->y = igl->winPosy;
        strcpy (wptr->title, pptr->title);
        wptr->parentWnd = pptr->wnd;
    }


    /* register window class */
    wc.style = CS_OWNDC;
    wc.lpfnWndProc = WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = igl->appInstance;
    wc.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor (NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject (BLACK_BRUSH);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = wptr->title;
    RegisterClass (&wc);

    /*
        create the window
        NOTE: window size and position will be set upon calling winconstraints()
        if prefposition() was not called, default position/size will be used
    */
    wflags = WS_POPUPWINDOW | WS_VISIBLE;
    if (pptr != NULL || (igl->windowFlags & IGL_WFLAGS_NOBORDER))
    {
        /* if it's a swinopen() window OR noborder() was called, the window will not have a border */
        wptr->flags |= IGL_WFLAGS_NOBORDER;
        if (pptr == NULL)
        {
            igl->windowFlags &= ~IGL_WFLAGS_NOBORDER;   /* reset for each window */
        }
    }
    else
    {
        wflags |= (WS_CAPTION | WS_SIZEBOX);
    }

    wptr->wnd = CreateWindow (wptr->title, wptr->title, wflags,
        wptr->x, wptr->y, wptr->width, wptr->height, NULL, NULL, igl->appInstance, NULL);
    if (wptr->wnd == NULL)
    {
        return (-1);
    }

    wptr->hdc = GetDC (wptr->wnd);
    memset (&pfd, 0, sizeof(PIXELFORMATDESCRIPTOR));
    pfd.nSize = sizeof (PIXELFORMATDESCRIPTOR);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER | PFD_SWAP_LAYER_BUFFERS;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = wptr->rgbPlanes;
    pfd.cDepthBits = 16;
    pfd.iLayerType = PFD_MAIN_PLANE;
    pfd.cAccumBits = wptr->acPlanes;
    pfd.cStencilBits = wptr->stenPlanes;
    pfd.cDepthBits = wptr->zbPlanes;
    pfd.bReserved = 49; /* = 0x31 = 00110001 = 1 underlay + 3 overlays */
    format = ChoosePixelFormat (wptr->hdc, &pfd);
    SetPixelFormat (wptr->hdc, format, &pfd);

    /* correct wptr's settings if pixel format differs */
    DescribePixelFormat (wptr->hdc, format, sizeof(PIXELFORMATDESCRIPTOR), &pfd);
    wptr->rgbPlanes = pfd.cColorBits;
    wptr->acPlanes = pfd.cAccumBits;
    wptr->stenPlanes = pfd.cStencilBits;
    wptr->zbPlanes = pfd.cDepthBits;

    /* create and enable the rendering contexts (RCs) for main and under/overlay planes */
    wptr->hrcs[IGL_WLAYER_NORMALDRAW] = wglCreateLayerContext (wptr->hdc, 0);
    wptr->hrcs[IGL_WLAYER_UNDERDRAW] = wglCreateLayerContext (wptr->hdc, -1);
    wptr->hrcs[IGL_WLAYER_OVERDRAW] = wglCreateLayerContext (wptr->hdc, 1);
    wptr->hrcs[IGL_WLAYER_PUPDRAW] = wglCreateLayerContext (wptr->hdc, 2);
    wptr->hrcs[IGL_WLAYER_CURSORDRAW] = wglCreateLayerContext (wptr->hdc, 3);

    /* main plane is the default */
    wglMakeCurrent (wptr->hdc, wptr->hrcs[IGL_WLAYER_NORMALDRAW]);
    SetActiveWindow (wptr->wnd);

    /* OpenGL heaven begins... */
    _igl_textInit (wptr);

    /* grab OpenGL extensions if present */
    /* NOTE: we have to do it here, since we don't have OpenGL in WinMain() yet! */
    if (!igl->initialized)
    {
        wglSwapIntervalEXT = (WGLSWAPINTERVALEXT)wglGetProcAddress ("wglSwapIntervalEXT");
        wglGetSwapIntervalEXT = (WGLGETSWAPINTERVALEXT)wglGetProcAddress ("wglGetSwapIntervalEXT");
        igl->initialized = TRUE;
    }


    return (idx);
}


/* find ID of the window by HWND */
static short
_igl_findWindowByHandle (HWND wnd)
{
    short i;


    if (wnd != NULL)
    {
        for (i=0; i < IGL_MAXWINDOWS; i++)
        {
            if (igl->openWindows[i].wnd == wnd)
            {
                return (i);
            }
        }
    }

    return (-1);
}


/* convert Win32 msgs (key/mouse events) to IrisGL devices */
#define KEYTR(_key) case #@_key: ret=_key##KEY; break
static int
_igl_winDeviceToIris (UINT msg, WPARAM wp, short *state)
{
    int ret = -1;


    if (msg == WM_KEYDOWN || msg == WM_KEYUP)
    {
        *state = (msg == WM_KEYDOWN);
        switch (wp)
        {
            KEYTR(A);
            KEYTR(B);
            KEYTR(C);
            KEYTR(D);
            KEYTR(E);
            KEYTR(F);
            KEYTR(G);
            KEYTR(H);
            KEYTR(I);
            KEYTR(J);
            KEYTR(K);
            KEYTR(L);
            KEYTR(M);
            KEYTR(N);
            KEYTR(O);
            KEYTR(P);
            KEYTR(Q);
            KEYTR(R);
            KEYTR(S);
            KEYTR(T);
            KEYTR(U);
            KEYTR(V);
            KEYTR(W);
            KEYTR(X);
            KEYTR(Y);
            KEYTR(Z);

            case '0': ret = ZEROKEY; break;
            case '1': ret = ONEKEY; break;
            case '2': ret = TWOKEY; break;
            case '3': ret = THREEKEY; break;
            case '4': ret = FOURKEY; break;
            case '5': ret = FIVEKEY; break;
            case '6': ret = SIXKEY; break;
            case '7': ret = SEVENKEY; break;
            case '8': ret = EIGHTKEY; break;
            case '9': ret = NINEKEY; break;

            case VK_NUMPAD0: ret = PAD0; break;
            case VK_NUMPAD1: ret = PAD1; break;
            case VK_NUMPAD2: ret = PAD2; break;
            case VK_NUMPAD3: ret = PAD3; break;
            case VK_NUMPAD4: ret = PAD4; break;
            case VK_NUMPAD5: ret = PAD5; break;
            case VK_NUMPAD6: ret = PAD6; break;
            case VK_NUMPAD7: ret = PAD7; break;
            case VK_NUMPAD8: ret = PAD8; break;
            case VK_NUMPAD9: ret = PAD9; break;
            case VK_DECIMAL: ret = PADPERIOD; break;
            case VK_SUBTRACT: ret = PADMINUS; break;

            case VK_F1: ret = F1KEY; break;
            case VK_F2: ret = F2KEY; break;
            case VK_F3: ret = F3KEY; break;
            case VK_F4: ret = F4KEY; break;
            case VK_F5: ret = F5KEY; break;
            case VK_F6: ret = F6KEY; break;
            case VK_F7: ret = F7KEY; break;
            case VK_F8: ret = F8KEY; break;
            case VK_F9: ret = F9KEY; break;
            case VK_F10: ret = F10KEY; break;
            case VK_F11: ret = F11KEY; break;
            case VK_F12: ret = F12KEY; break;

            case VK_ESCAPE: ret = ESCKEY; break;
            case VK_TAB: ret = TABKEY; break;
            case VK_RETURN: ret = RETKEY; break; /* should it set PADENTER, too? */
            case VK_SPACE: ret = SPACEKEY; break;
            case VK_BACK: ret = BACKSPACEKEY; break;
            case VK_LEFT: ret = LEFTARROWKEY; break;
            case VK_DOWN: ret = DOWNARROWKEY; break;
            case VK_RIGHT: ret = RIGHTARROWKEY; break;
            case VK_UP: ret = UPARROWKEY; break;
            case VK_PRINT: ret = PRINTSCREENKEY; break;
            case VK_SCROLL: ret = SCROLLLOCKKEY; break;
            case VK_PAUSE: ret = PAUSEKEY; break;
            case VK_INSERT: ret = INSERTKEY; break;
            case VK_HOME: ret = HOMEKEY; break;
            case VK_END: ret = ENDKEY; break;
            case VK_NUMLOCK: ret = NUMLOCKKEY; break;

            /* mouse buttons */
            case VK_LBUTTON: ret = LEFTMOUSE; break;
            case VK_RBUTTON: ret = RIGHTMOUSE; break;
            case VK_MBUTTON: ret = MIDDLEMOUSE; break;
        }
    }
    else if (msg == WM_LBUTTONUP || msg == WM_LBUTTONDOWN)
    {
        *state = (msg == WM_LBUTTONDOWN);
        ret = LEFTMOUSE;
    }
    else if (msg == WM_RBUTTONUP || msg == WM_RBUTTONDOWN)
    {
        *state = (msg == WM_RBUTTONDOWN);
        ret = RIGHTMOUSE;
    }
    else if (msg == WM_MBUTTONUP || msg == WM_MBUTTONDOWN)
    {
        *state = (msg == WM_MBUTTONDOWN);
        ret = MIDDLEMOUSE;
    }


    return (ret);
}
#undef KEYTR


/*
    process WM_KEY/MOUSE events and place them in appropriate device queues.
    events are removed once user chooses to process them (getvaluator()/getbutton()/getdev()/qread())
*/
static void
_igl_processDevice (UINT msg, WPARAM wp, LPARAM lp)
{
    int dev, devTie;
    short state;
    POINT p;


    /* refresh the mouse position for 'internal' purposes =) */
    GetCursorPos (&p);
    igl->devices[MOUSEX] = p.x;
    igl->devices[MOUSEY] = p.y;


    dev = _igl_winDeviceToIris (msg, wp, &state);
    /* normal devices */
    if (dev != -1)
    {
        /* if device is queued, we have to qenter() it */
        if (igl->deviceQueue[dev])
        {
            /* NOTE: state indicates whether a device is 'up' or 'down' */
            qenter ((Device)dev, state);

            /* if it's a KEYBD device and it's 'down', qenter KEYBD as well */
            if (ISKEYBD(dev) && state == 1 && igl->deviceQueue[KEYBD])
            {
                qenter (KEYBD, (short)dev);
            }

            /* if device is tied, we have to qenter() its ties */
            devTie = igl->tiedValuators[dev*2];
            if (devTie != NULLDEV)
            {
                qenter ((Device)devTie, (short)igl->devices[devTie]);

                devTie = igl->tiedValuators[dev*2+1];
                if (devTie != NULLDEV)
                {
                    qenter ((Device)devTie, (short)igl->devices[devTie]);
                }
            }
        }
    }
    /* 'abnormal' devices */
    else
    {
        /* this one has two connected devices - MOUSEX and MOUSEY */
        if (msg == WM_MOUSEMOVE)
        {
            if (igl->deviceQueue[MOUSEX])
            {
                qenter (MOUSEX, (short)igl->devices[MOUSEX]);
            }
            if (igl->deviceQueue[MOUSEY])
            {
                qenter (MOUSEY, (short)igl->devices[MOUSEY]);
            }
        }
    }
}


LRESULT CALLBACK
WndProc (HWND wnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    short wid = -1;


    switch (msg)
    {
        case WM_CREATE:
        case WM_DESTROY:
            return (0);

        case WM_CLOSE:
            PostQuitMessage (0);
            return (0);

        case WM_PAINT:
#if 0
            if (igl->deviceQueue[REDRAW])
            {
                wid = _igl_findWindowByHandle (wnd);
                if (wid != -1)
                {
                    qenter (REDRAW, wid);
                }
            }
#else
            /* manual says: the REDRAW token is queued automatically */
            qenter (REDRAW, wid);
#endif
            return (DefWindowProc(wnd, msg, wParam, lParam));

        case WM_MOVE:
        case WM_SIZE:
            wid = _igl_findWindowByHandle (wnd);
            if (wid != -1)
            {
                igl_windowT *wptr = &igl->openWindows[wid];

                if (msg == WM_MOVE)
                {
                    wptr->x = LOWORD (lParam);
                    wptr->y = HIWORD (lParam);
                }
                else
                {
                    wptr->width = LOWORD (lParam);
                    wptr->height = HIWORD (lParam);
                }
            }
            return (0);

        case WM_EXITSIZEMOVE:
            wid = _igl_findWindowByHandle (wnd);
            if (wid != -1)
            {
#if 0
                igl_windowT *wptr = &igl->openWindows[wid];

                /* check for aspect */
                if (wptr->aspectX != -1 && wptr->aspectY != -1 &&
                    wptr->aspectX/wptr->aspectY != wptr->width/wptr->height)
                {
                    wptr->height = wptr->width*wptr->aspectY/wptr->aspectX;
                    SetWindowPos (wptr->wnd, HWND_NOTOPMOST, 0, 0,
                            wptr->width, wptr->height, SWP_NOMOVE);
                }
#endif

                /* this probably has to be forced here? */
                qenter (REDRAW, wid);
            }
            return (0);

        case WM_KEYUP:
        case WM_KEYDOWN:
        case WM_MOUSEMOVE:
        case WM_LBUTTONDOWN:
        case WM_LBUTTONUP:
        case WM_RBUTTONDOWN:
        case WM_RBUTTONUP:
        case WM_MBUTTONDOWN:
        case WM_MBUTTONUP:
            _igl_processDevice (msg, wParam, lParam);
#if 1
            /* debug mode - ESC kills the app */
            if (msg == WM_KEYDOWN && wParam == VK_ESCAPE)
            {
                PostQuitMessage (0);
            }
#endif
            return (0);

        case WM_SETFOCUS:
            wid = _igl_findWindowByHandle (wnd);
            if (wid != -1)
            {
                if (igl->deviceQueue[INPUTCHANGE])
                {
                    qenter (INPUTCHANGE, wid);
                }
                if (igl->deviceQueue[REDRAW])
                {
                    qenter (REDRAW, wid);
                }
            }
            return (0);

        default:
            return (DefWindowProc (wnd, msg, wParam, lParam));
    }
}


#if 0
____________________________ window functions ____________________________
() {}
#endif
/* DESC: prefsize - specifies the preferred size of a graphics window */
void
prefsize (int width, int height)
{
    igl->winWidth = (width < 1) ? IGL_WINDOWWIDTH : width;
    igl->winHeight = (height < 1) ? IGL_WINDOWHEIGHT : height;
}


/* DESC: maxsize - specifies the maximum size of a graphics window */
void
maxsize (long width, long height)
{
    igl->winWidth = (width < 1) ? IGL_WINDOWWIDTH : width;
    igl->winHeight = (height < 1) ? IGL_WINDOWHEIGHT : height;
}


/* DESC: minsize - specifies the minimum size of a graphics window */
void
minsize (long width, long height)
{
    /* TBD: is minsize really relevant on Win32 or can it be the same as maxsize */
    igl->winWidth = (width < 1) ? IGL_WINDOWWIDTH : width;
    igl->winHeight = (height < 1) ? IGL_WINDOWHEIGHT : height;
}


/* DESC: prefposition - specifies the preferred location and size of a graphics window */
void
prefposition (int x0, int x1, int y0, int y1)
{
    if (x1 < x0 || y1 < y0)
    {
        return;
    }

    igl->winPosx = x0;
    igl->winPosy = y0;
    igl->winWidth = x1-x0;
    igl->winHeight= y1-y0;
    if (igl->winWidth < 1)
    {
        igl->winWidth = IGL_WINDOWWIDTH;
    }
    if (igl->winHeight < 1)
    {
        igl->winHeight = IGL_WINDOWHEIGHT;
    }
}


/* DESC: winopen - creates a graphics window */
long
winopen (String windowTitle)
{
    return (_igl_createWindow(windowTitle, -1));
}


/* DESC: swinopen - creates a graphics subwindow */
long
swinopen (long parent)
{
    IGL_CHECKINIT (-1);
    if (parent < 0 || parent > IGL_MAXWINDOWS || igl->openWindows[parent].wnd == NULL)
    {
        return (-1);
    }

    return (_igl_createWindow(NULL, parent));
}


/* DESC: winclose -  closes the identified graphics window */
void
winclose (long gwid)
{
    int i;


    IGL_CHECKINITV ();

    if (gwid < 0 || gwid >= IGL_MAXWINDOWS)
    {
        return;
    }

    /*
        TBD: does parent's close also close al children?
        since we passed parentWnd to CreateWindow() in swinopen(), it should...
    */
    DestroyWindow (igl->openWindows[gwid].wnd);
    memset (&igl->openWindows[gwid], 0, sizeof(igl_windowT));

    /* find the new current window! */
    for (i=0; i < IGL_MAXWINDOWS; i++)
    {
        if (igl->openWindows[i].wnd != NULL)
        {
            igl->currentWindow = i;
            wglMakeCurrent (igl->openWindows[i].hdc, igl->openWindows[i].hrcs[IGL_WLAYER_NORMALDRAW]);
            return;
        }
    }
    igl->currentWindow = -1;    /* this was the last window that we just closed */
    /* TBD: what do we do here? should the app exit? */
}


/* DESC: winconstraints - binds window constraints to the current window */
void
winconstraints ()
{
    igl_windowT *wptr;


    IGL_CHECKINITV ();

    wptr = IGL_CTX ();
    wptr->x = igl->winPosx;
    wptr->y = igl->winPosy;
    wptr->width = igl->winWidth;
    wptr->height = igl->winHeight;

    SetWindowPos (wptr->wnd, HWND_NOTOPMOST,
        wptr->x, wptr->y, wptr->width, wptr->height, SWP_SHOWWINDOW);
}


/* DESC: winposition - changes the size and position of the current graphics window */
void
winposition (int x0, int x1, int y0, int y1)
{
    igl_windowT *wptr;


    IGL_CHECKINITV ();

    if (x1 < x0 || y1 < y0)
    {
        return;
    }

    wptr = IGL_CTX ();
    wptr->x = x0;
    wptr->y = y0;
    wptr->width = x1-x0;
    wptr->height = y1-y0;
    if (wptr->width < 1)
    {
        wptr->width = IGL_WINDOWWIDTH;
    }
    if (wptr->height < 1)
    {
        wptr->height = IGL_WINDOWHEIGHT;
    }

    SetWindowPos (wptr->wnd, HWND_NOTOPMOST, wptr->x, wptr->y, wptr->width, wptr->height,
        SWP_SHOWWINDOW);
}


/* DESC: winattach - obsolete routine */
long
winattach ()
{
    /* obsoleted by SGI */
    return (0);
}


/* DESC: winget - returns the identifier of the current graphics window */
long
winget ()
{
    return (igl->currentWindow);
}


/* DESC: winset - sets the current graphics window */
void
winset (long gwid)
{
    IGL_CHECKINITV ();

    if (gwid >= 0 && gwid < IGL_MAXWINDOWS && gwid != igl->currentWindow)
    {
        igl->currentWindow = gwid;
        wglMakeCurrent (igl->openWindows[gwid].hdc, igl->openWindows[gwid].hrcs[IGL_WLAYER_NORMALDRAW]);
    }
}


/* DESC: winpush - places the current graphics window behind all other windows */
void
winpush ()
{
    IGL_CHECKINITV ();
    SetWindowPos (IGL_CTX()->wnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
}


/* DESC: winpop - moves the current graphics window in front of all other windows */
void
winpop ()
{
    IGL_CHECKINITV ();
    SetWindowPos (IGL_CTX()->wnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
}


/* DESC: winmove - moves the current graphics window by its lower-left corner */
void
winmove (long orgx, long orgy)
{
    igl_windowT *wptr;


    IGL_CHECKINITV ();

    wptr = IGL_CTX ();
    /* convert lower-left (IrisGL/OpenGL) to upper-left (Win32) coords */
    wptr->x = orgx;
    wptr->y = orgy - wptr->height;
    SetWindowPos (wptr->wnd, HWND_TOPMOST, wptr->x, wptr->y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
}


/* DESC: wintitle - adds a title bar to the current graphics window */
void
wintitle (String name)
{
    long wndStyle;
    igl_windowT *wptr;


    IGL_CHECKINITV ();

    wptr = IGL_CTX ();
    wndStyle = GetWindowLong (wptr->wnd, GWL_STYLE);
    if (wndStyle & WS_CAPTION)
    {
        /* wintitle("") clears the window title. does it clear WS_CAPTION? */
        SetWindowText (wptr->wnd, name);
    }
    /* TBD: what if we don't have a caption (e.g. swinopen()). do we add it? */
    else
    {
    }
}


/* DESC: ??? (gets the window id at specified coordinates) */
long
winat (short x, short y)
{
    int i;
    igl_windowT *wptr;


    IGL_CHECKINIT (-1);

#if 0
    /* first, process active window */
    i = _igl_findWindowByHandle (GetActiveWindow());
    if (i != -1)
    {
        wptr = &igl->openWindows[i];
        if (wptr->wnd != NULL && x >= wptr->x && y >= wptr->y &&
            x <= (wptr->x + wptr->width) && y <= (wptr->y + wptr->height))
        {
            return (i);
        }
    }
#endif

    /* not found, try inactive */
    for (i=0; i < IGL_MAXWINDOWS; i++)
    {
        wptr = &igl->openWindows[i];
        if (wptr->wnd != NULL && x >= wptr->x && y >= wptr->y &&
            x <= (wptr->x + wptr->width) && y <= (wptr->y + wptr->height))
        {
            return (i);
        }
    }

    return (-1);
}


/* DESC: ??? (gets the window id at specified coordinates) */
long
gl_winat (short x, short y)
{
    return (winat(x, y));
}


/* DESC: keepaspect - specifies the aspect ratio of a graphics window */
void
keepaspect (int x, int y)
{
    IGL_CHECKINITV ();

    if (x >= 1 && x <= 32767 && y >= 1 && y <= 32767)
    {
        IGL_CTX ()->aspectX = x;
        IGL_CTX ()->aspectY = x;
    }
}


/* DESC: getsize - returns the size of a graphics window */
void
getsize (long *x, long *y)
{
    IGL_CHECKINITV ();

    if (x != NULL)
    {
        *x = IGL_CTX()->width;
    }
    if (y != NULL)
    {
        *y = IGL_CTX()->height;
    }
}


/* DESC: getorigin - returns the position of a graphics window */
void
getorigin (long *x, long *y)
{
    IGL_CHECKINITV ();

    if (x != NULL)
    {
        *x = IGL_CTX()->x;
    }
    if (y != NULL)
    {
        *y = IGL_CTX()->y;
    }
}


/* DESC: gconfig - reconfigures the GL modes of the current window */
void
gconfig ()
{
    igl_windowT *wptr;
    int format, windowChanged = 0;
    PIXELFORMATDESCRIPTOR pfd;


    IGL_CHECKINITV ();

    reshapeviewport ();
    wptr = IGL_CTX ();

    /* retrieve window's pixel format */
    format = GetPixelFormat (wptr->hdc);
    if (format <= 0)
    {
        return;
    }
    DescribePixelFormat (wptr->hdc, format, sizeof(PIXELFORMATDESCRIPTOR), &pfd);


    /* set by RGBmode()/cmode()/singlebuffer/doublebuffer()/stereobuffer()/monobuffer() */
    /* TBD: what do we do with stereobuffer()/monobuffer()s? */
    if (wptr->flags != wptr->newFlags)
    {
        wptr->flags = wptr->newFlags;
        windowChanged = 1;
    }

    /* set by acsize() */
    if (wptr->acPlanes != pfd.cAccumBits)
    {
        pfd.cAccumBits = wptr->acPlanes;
        windowChanged = 1;
    }

    /* set by stensize() */
    if (wptr->stenPlanes != pfd.cStencilBits)
    {
        pfd.cStencilBits = wptr->stenPlanes;
        windowChanged = 1;
    }

    /* set by zbsize() */
    if (wptr->zbPlanes != pfd.cDepthBits)
    {
        pfd.cDepthBits = wptr->zbPlanes;
        windowChanged = 1;
    }

    /* set by RGBsize() */
    if (wptr->rgbPlanes != pfd.cColorBits)
    {
        pfd.cColorBits = wptr->rgbPlanes;
        windowChanged = 1;
    }


    /* TBD */
    /* set by mssize() */
    /* set by multimap() */
    /* set by onemap() */
    /* set by overlay() */
    /* set by underlay() */


    /**************************************
        process the changes
    **************************************/
    format = ChoosePixelFormat (wptr->hdc, &pfd);
    SetPixelFormat (wptr->hdc, format, &pfd);

    /* correct wptr's settings if pixel format differs */
    DescribePixelFormat (wptr->hdc, format, sizeof(PIXELFORMATDESCRIPTOR), &pfd);
    wptr->acPlanes = pfd.cAccumBits;
    wptr->stenPlanes = pfd.cStencilBits;
    wptr->zbPlanes = pfd.cDepthBits;
    wptr->rgbPlanes = pfd.cColorBits;

    /* adjust double/fake singlebuffering */
    glDrawBuffer ((wptr->flags & IGL_WFLAGS_DOUBLEBUFFER) ? GL_BACK : GL_FRONT);

    /* this has to be done here to get the first redraw properly (?) */
    qenter (REDRAW, (short)igl->currentWindow);
}


/* DESC: getgconfig - gets the size of a buffer or a state in the current buffer configuration */
long
getgconfig (long buffer)
{
    int buf[2];
    igl_windowT *wptr;


    IGL_CHECKINIT (0);

    wptr = IGL_CTX ();
    switch (buffer)
    {
        case GC_BITS_CMODE:
            return ((wptr->flags & IGL_WFLAGS_RGBA) ? 0 : wptr->rgbPlanes);

        case GC_BITS_RED:
        case GC_BITS_GREEN:
        case GC_BITS_BLUE:
        case GC_BITS_ALPHA:
            return (wptr->rgbPlanes/4); /* TBD */

        case GC_BITS_ZBUFFER:
            return (wptr->zbPlanes);

        case GC_ZMIN:
        case GC_ZMAX:
            glGetIntegerv (GL_DEPTH_RANGE, buf);
            return ((buffer == GC_ZMIN) ? buf[0] : buf[1]);

        case GC_BITS_STENCIL:
            return (wptr->stenPlanes);

        case GC_BITS_ACBUF:
            return (wptr->acPlanes);

        case GC_MS_SAMPLES:
            return (0);

        case GC_BITS_MS_ZBUFFER:
            return (0);

        case GC_MS_ZMIN:
            return (0);

        case GC_MS_ZMAX:
            return (0);

        case GC_BITS_MS_STENCIL:
            return (0);

        case GC_STEREO:
            return (wptr->flags & IGL_WFLAGS_STEREOBUFFER);

        case GC_DOUBLE:
            return (wptr->flags & IGL_WFLAGS_DOUBLEBUFFER);

        default:
            return (0);
    }
}


/* DESC: getplanes - returns the number of available bitplanes */
long
getplanes ()
{
    IGL_CHECKINIT (-1);
    /* color-index mode has a fixed palette of 4096 (2^12) entries */
    return ((IGL_CTX()->flags & IGL_WFLAGS_RGBA) ? IGL_CTX()->rgbPlanes : 12);
}


/* DESC: fullscrn - allows a program write to the entire screen */
void
fullscrn ()
{
    igl_windowT *wptr;
    DEVMODE devMode;


    IGL_CHECKINITV ();

    wptr = IGL_CTX ();
    if (wptr->flags & IGL_WFLAGS_FULLSCREEN)
    {
        return;
    }

    memset (&devMode, 0, sizeof(DEVMODE));
    devMode.dmSize = sizeof (DEVMODE);
    EnumDisplaySettings (NULL, ENUM_CURRENT_SETTINGS, &devMode);

    devMode.dmPelsWidth = wptr->width;
    devMode.dmPelsHeight = wptr->height;

    /* test the settings and adjust if necessary */
    if (ChangeDisplaySettings(&devMode, CDS_TEST) != DISP_CHANGE_SUCCESSFUL)
    {
        devMode.dmPelsWidth = IGL_WINDOWWIDTH;
        devMode.dmPelsHeight = IGL_WINDOWHEIGHT;
        if (ChangeDisplaySettings(&devMode, CDS_TEST) != DISP_CHANGE_SUCCESSFUL)
        {
            return;
        }
    }

    /* switch to fullscreen and update the viewport */
    if (ChangeDisplaySettings(&devMode, CDS_FULLSCREEN) == DISP_CHANGE_SUCCESSFUL)
    {
        long wndStyle = GetWindowLong (wptr->wnd, GWL_STYLE);

        /* hide the window title */
        if (wndStyle != 0)
        {
            /* save for later, when endfullscrn() is called */
            wptr->style = wndStyle;

            wndStyle &= ~WS_CAPTION;
            wndStyle &= ~WS_SIZEBOX;
            SetWindowLong (wptr->wnd, GWL_STYLE, wndStyle);
            SetWindowPos (wptr->wnd, HWND_TOPMOST, 0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
        }

        wptr->width = devMode.dmPelsWidth;
        wptr->height = devMode.dmPelsHeight;
        wptr->flags |= IGL_WFLAGS_FULLSCREEN;
        glViewport (0, 0, wptr->width, wptr->height);
    }
}


/* DESC: endfullscrn - ends full-screen mode */
void
endfullscrn ()
{
    igl_windowT *wptr;
    DEVMODE devMode;


    IGL_CHECKINITV ();

    wptr = IGL_CTX ();
    if (!(wptr->flags & IGL_WFLAGS_FULLSCREEN))
    {
        return;
    }

    /* restore the screen */
    memset (&devMode, 0, sizeof(DEVMODE));
    devMode.dmSize = sizeof (DEVMODE);
    ChangeDisplaySettings (&devMode, 0);

    /* restore the window style */
    SetWindowLong (wptr->wnd, GWL_STYLE, wptr->style);
    SetWindowPos (wptr->wnd, HWND_TOPMOST, 0, 0, 0, 0,
        SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
}


/* DESC: foreground - prevents a graphical process from being put into the background */
void
foreground ()
{
    /* do we need this? (man page says "useful for debugging on...") */
}


/* DESC: fudge - specifies fudge values that are added to a graphics window */
void
fudge (long xfudge, long yfudge)
{
    /* do we need "interior window borders"? */
}


/* DESC: getwscrn - returns the screen upon which the current window appears */
long
getwscrn ()
{
    /* we're always on screen 0, i guess */
    return (0);
}


/* DESC: noborder - specifies a window without any borders */
void
noborder ()
{
    IGL_CHECKINITV ();
    igl->windowFlags |= IGL_WFLAGS_NOBORDER;
}


