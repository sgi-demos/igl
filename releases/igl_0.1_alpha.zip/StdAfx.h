#ifndef AFX_STDAFX_H__6B7FC262_690B_11D6_8BB3_BC289994A61C__INCLUDED_
#define AFX_STDAFX_H__6B7FC262_690B_11D6_8BB3_BC289994A61C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "gl.h"


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif /* AFX_STDAFX_H__6B7FC262_690B_11D6_8BB3_BC289994A61C__INCLUDED_ */


